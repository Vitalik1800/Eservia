package com.eservia.booking.ui.gallery;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

import java.util.List;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface GalleryView extends LoadingView {

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void onStartPosition(int startPosition);

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void initWith(List<String> urls);
}
