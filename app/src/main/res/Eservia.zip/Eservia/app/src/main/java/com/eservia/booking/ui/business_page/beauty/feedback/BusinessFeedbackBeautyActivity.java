package com.eservia.booking.ui.business_page.beauty.feedback;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.eservia.booking.R;
import com.eservia.booking.common.view.BaseActivity;
import com.eservia.booking.common.view.ClearFocusLayoutListener;
import com.eservia.booking.util.BusinessUtil;
import com.eservia.booking.util.MessageUtil;
import com.eservia.booking.util.ValidatorUtil;
import com.eservia.booking.util.ViewUtil;
import com.eservia.booking.util.WindowUtils;
import com.eservia.common.view.SimpleTextWatcher;
import com.eservia.model.entity.Business;
import com.eservia.mvp.presenter.InjectPresenter;
import com.eservia.simpleratingbar.SimpleRatingBar;
import com.eservia.utils.KeyboardUtil;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class BusinessFeedbackBeautyActivity extends BaseActivity implements BusinessFeedbackBeautyView {

    @BindView(R.id.coordinator)
    CoordinatorLayout coordinator;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.rlCardHolderRatingSelector)
    RelativeLayout rlCardHolderRatingSelector;

    @BindView(R.id.cvContainerRatingSelector)
    CardView cvContainerRatingSelector;

    @BindView(R.id.rlCardHolderCommentEditor)
    RelativeLayout rlCardHolderCommentEditor;

    @BindView(R.id.cvContainerCommentEditor)
    CardView cvContainerCommentEditor;

    @BindView(R.id.rvQuality)
    RecyclerView rvQuality;

    @BindView(R.id.rvPurity)
    RecyclerView rvPurity;

    @BindView(R.id.rvConvenience)
    RecyclerView rvConvenience;

    @BindView(R.id.sbQuality)
    SeekBar sbQuality;

    @BindView(R.id.sbPurity)
    SeekBar sbPurity;

    @BindView(R.id.sbConvenience)
    SeekBar sbConvenience;

    @BindView(R.id.etFeedback)
    EditText etFeedback;

    @BindView(R.id.ivEdit)
    ImageView ivEdit;

    @BindView(R.id.rbTotalRating)
    SimpleRatingBar rbTotalRating;

    @BindView(R.id.tvRating)
    TextView tvRating;

    @BindView(R.id.pbProgress)
    ProgressBar pbProgress;

    @BindView(R.id.layout_accept)
    View layout_accept;

    @BindView(R.id.tvAccept)
    TextView tvAccept;

    @BindView(R.id.ivAccept)
    ImageView ivAccept;

    @InjectPresenter
    BusinessFeedbackBeautyPresenter mPresenter;

    private StarAdapter mStarAdapterQuality;

    private StarAdapter mStarAdapterPurity;

    private StarAdapter mStarAdapterConvenience;

    public static void start(Context context, Business business) {
        EventBus.getDefault().postSticky(business);
        Intent starter = new Intent(context, BusinessFeedbackBeautyActivity.class);
        context.startActivity(starter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_feedback_beauty);
        WindowUtils.setLightStatusBar(this);
        setUnbinder(ButterKnife.bind(this));
        initViews();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @OnClick(R.id.layout_accept)
    public void onSendFeedbackClicked() {
        checkForErrorsAndSend();
    }

    @OnClick(R.id.ivEdit)
    public void onEditClicked() {
        etFeedback.requestFocus();
        KeyboardUtil.showSoftKeyboard(this);
        ViewUtil.moveCursorToEnd(etFeedback);
    }

    @Override
    public void showProgress() {
        pbProgress.setVisibility(View.VISIBLE);
        layout_accept.setVisibility(View.INVISIBLE);
    }

    @Override
    public void hideProgress() {
        pbProgress.setVisibility(View.GONE);
        layout_accept.setVisibility(View.VISIBLE);
    }

    @Override
    public void initMaxMinDefault(int maxRating, int minRating, int defaultRating) {
        sbQuality.setMax(maxRating);
        sbQuality.setProgress(defaultRating);

        sbPurity.setMax(maxRating);
        sbPurity.setProgress(defaultRating);

        sbConvenience.setMax(maxRating);
        sbConvenience.setProgress(defaultRating);
    }

    @Override
    public void setQualityStars(List<StarItem> stars) {
        mStarAdapterQuality.replaceAll(stars);
    }

    @Override
    public void setPurityStars(List<StarItem> stars) {
        mStarAdapterPurity.replaceAll(stars);
    }

    @Override
    public void setConvenienceStars(List<StarItem> stars) {
        mStarAdapterConvenience.replaceAll(stars);
    }

    @Override
    public void onTotalRating(float rating) {
        rbTotalRating.setRating(BusinessUtil.starsRating(rating));
        tvRating.setText(BusinessUtil.formatRating(rating));
    }

    @Override
    public void onCreateCommentSuccess() {
        MessageUtil.showToast(this, R.string.success_send_business_feedback);
        finish();
    }

    @Override
    public void onCreateCommentFailed(Throwable error) {
        MessageUtil.showSnackbar(coordinator, error);
    }

    private void checkForErrorsAndSend() {
        KeyboardUtil.hideSoftKeyboard(this);

        setError();

        if (!hasErrors()) {
            mPresenter.onSendFeedbackClicked();
        }
    }

    private void setError() {
        String comment = etFeedback.getText().toString();
        if (!comment.isEmpty()) {
            etFeedback.setError(ValidatorUtil.isLongMessageValid(this, comment));
        } else {
            etFeedback.setError(null);
        }
    }

    private boolean hasErrors() {
        boolean error = false;
        if (etFeedback.getError() != null) {
            etFeedback.requestFocus();
            error = true;
        }
        return error;
    }

    private void initViews() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setElevation(0);

        ViewUtil.setCardOutlineProvider(this, rlCardHolderRatingSelector, cvContainerRatingSelector);
        ViewUtil.setCardOutlineProvider(this, rlCardHolderCommentEditor, cvContainerCommentEditor);

        initStarLists();

        initSeekBars();

        initFeedback();

        tvAccept.setText(getResources().getString(R.string.send));
        ivAccept.setVisibility(View.GONE);
    }

    private void initFeedback() {
        etFeedback.getViewTreeObserver().addOnGlobalLayoutListener(new ClearFocusLayoutListener(
                etFeedback, new View[]{etFeedback}));

        etFeedback.setFilters(new InputFilter[]{new InputFilter.LengthFilter(
                ValidatorUtil.MAX_ESERVIA_FEEDBACK_LENGTH)});

        ViewUtil.setOnTouchListenerForVerticalScroll(etFeedback);

        etFeedback.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void textChanged(String s) {
                if (etFeedback.getError() != null) {
                    setError();
                    etFeedback.requestFocus();
                }
                mPresenter.onCommentChanged(s);
            }
        });
    }

    private void initStarLists() {
        mStarAdapterQuality = new StarAdapter(this, mPresenter);
        mStarAdapterPurity = new StarAdapter(this, mPresenter);
        mStarAdapterConvenience = new StarAdapter(this, mPresenter);

        rvQuality.setAdapter(mStarAdapterQuality);
        rvPurity.setAdapter(mStarAdapterPurity);
        rvConvenience.setAdapter(mStarAdapterConvenience);

        rvQuality.setHasFixedSize(true);
        rvPurity.setHasFixedSize(true);
        rvConvenience.setHasFixedSize(true);

        GridLayoutManager layoutManagerQuality = new GridLayoutManager(this, 5,
                GridLayoutManager.VERTICAL, false);
        GridLayoutManager layoutManagerPurity = new GridLayoutManager(this, 5,
                GridLayoutManager.VERTICAL, false);
        GridLayoutManager layoutManagerConvenience = new GridLayoutManager(this, 5,
                GridLayoutManager.VERTICAL, false);

        rvQuality.setLayoutManager(layoutManagerQuality);
        rvPurity.setLayoutManager(layoutManagerPurity);
        rvConvenience.setLayoutManager(layoutManagerConvenience);
    }

    private void initSeekBars() {
        SeekBarListener seekBarListener = new SeekBarListener();
        sbQuality.setOnSeekBarChangeListener(seekBarListener);
        sbPurity.setOnSeekBarChangeListener(seekBarListener);
        sbConvenience.setOnSeekBarChangeListener(seekBarListener);
    }

    private class SeekBarListener implements SeekBar.OnSeekBarChangeListener {

        @Override
        public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
            if (seekBar.equals(sbQuality)) {
                mPresenter.onQualityChanged(i);
            } else if (seekBar.equals(sbPurity)) {
                mPresenter.onPurityChanged(i);
            } else if (seekBar.equals(sbConvenience)) {
                mPresenter.onConvenienceChanged(i);
            }
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    }
}
