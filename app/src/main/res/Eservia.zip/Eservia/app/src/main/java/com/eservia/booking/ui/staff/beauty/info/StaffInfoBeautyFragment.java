package com.eservia.booking.ui.staff.beauty.info;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;

import com.eservia.booking.R;
import com.eservia.booking.ui.gallery.GalleryActivity;
import com.eservia.booking.ui.gallery.GalleryExtra;
import com.eservia.booking.ui.home.BaseHomeFragment;
import com.eservia.booking.util.BusinessUtil;
import com.eservia.booking.util.ImageUtil;
import com.eservia.booking.util.ViewUtil;
import com.eservia.model.entity.BeautyStaff;
import com.eservia.mvp.presenter.InjectPresenter;
import com.eservia.utils.StringUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class StaffInfoBeautyFragment extends BaseHomeFragment implements StaffInfoBeautyView {

    @BindView(R.id.fragment)
    LinearLayout fragment;

    @BindView(R.id.rlCardHolderMainInfo)
    RelativeLayout rlCardHolderMainInfo;

    @BindView(R.id.cvContainerMainInfo)
    CardView cvContainerMainInfo;

    @BindView(R.id.rlInfoHeader)
    RelativeLayout rlInfoHeader;

    @BindView(R.id.ivImage)
    ImageView ivImage;

    @BindView(R.id.tvName)
    TextView tvName;

    @BindView(R.id.tvPosition)
    TextView tvPosition;

    @BindView(R.id.tvDescription)
    TextView tvDescription;

    @InjectPresenter
    StaffInfoBeautyPresenter mPresenter;

    private Activity mActivity;

    public static StaffInfoBeautyFragment newInstance() {
        return new StaffInfoBeautyFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_staff_info_beauty, container, false);
        mActivity = getActivity();
        setUnbinder(ButterKnife.bind(this, view));
        initViews();
        return view;
    }

    @OnClick(R.id.rlInfoHeader)
    public void onHeaderClick() {
        mPresenter.onStaffImageClick();
    }

    @Override
    public void refresh() {
    }

    @Override
    public void willBeDisplayed() {
    }

    @Override
    public void willBeHidden() {
    }

    @Override
    public void showProgress() {
    }

    @Override
    public void hideProgress() {
    }

    @Override
    public void onStaff(@Nullable BeautyStaff staff) {
        if (staff == null) {
            fragment.setVisibility(View.INVISIBLE);
        } else {
            fragment.setVisibility(View.VISIBLE);

            bindStaff(staff);
        }
    }

    @Override
    public void showGalleryActivity(GalleryExtra extra) {
        GalleryActivity.start(mActivity, extra);
    }

    private void bindStaff(BeautyStaff staff) {
        tvName.setText(BusinessUtil.getStaffFullName(staff.getFirstName(), staff.getLastName()));

        if (!StringUtil.isEmpty(staff.getPosition())) {
            tvPosition.setVisibility(View.VISIBLE);
            tvPosition.setText(staff.getPosition());
        } else {
            tvPosition.setVisibility(View.GONE);
            tvPosition.setText("");
        }

        if (!StringUtil.isEmpty(staff.getDescription())) {
            tvDescription.setVisibility(View.VISIBLE);
            tvDescription.setText(staff.getDescription());
        } else {
            tvDescription.setVisibility(View.GONE);
            tvDescription.setText("");
        }

        ImageUtil.displayStaffImageRound(mActivity, ivImage, staff.getPhoto(),
                R.drawable.user_man_big);
    }

    private void initViews() {
        ViewUtil.setCardOutlineProvider(mActivity, rlCardHolderMainInfo, cvContainerMainInfo);
    }
}
