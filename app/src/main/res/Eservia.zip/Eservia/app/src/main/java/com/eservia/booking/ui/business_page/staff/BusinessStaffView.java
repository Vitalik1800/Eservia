package com.eservia.booking.ui.business_page.staff;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.model.entity.BeautyStaff;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

import java.util.List;

public interface BusinessStaffView extends LoadingView {

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void onStaffLoadingSuccess(List<BeautyStaff> staffList);

    @StateStrategyType(value = SkipStrategy.class)
    void onStaffLoadingFailed(Throwable throwable);

    @StateStrategyType(value = SkipStrategy.class)
    void showStaffDetailBeautyPage(BeautyStaff staff);
}
