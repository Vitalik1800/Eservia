package com.eservia.booking.util;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;

import androidx.annotation.DrawableRes;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.MultiTransformation;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.eservia.model.entity.PhotoSize;
import com.eservia.model.remote.UrlList;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;

import jp.wasabeef.glide.transformations.MaskTransformation;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class ImageUtil {

    public static String getRealPathFromUri(Context context, Uri contentUri) {
        String result;
        Cursor cursor = context.getContentResolver().query(
                contentUri, null, null, null, null);
        if (cursor == null) {
            result = contentUri.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }

    public static String getImageNameFromUri(Context context, Uri contentUri) {
        String imageRealPath = ImageUtil.getRealPathFromUri(context, contentUri);
        File imageFile = new File(imageRealPath);
        return imageFile.getName();
    }

    public static String getImageNameFromPath(String realPath) {
        File imageFile = new File(realPath);
        return imageFile.getName();
    }

    public static File getFileFromUri(Context context, Uri contentUri) {
        String imageRealPath = ImageUtil.getRealPathFromUri(context, contentUri);
        return new File(imageRealPath);
    }

    public static Bitmap getBitmapFromUri(Context context, Uri contentUri) throws FileNotFoundException {
        final InputStream imageStream = context.getContentResolver().openInputStream(contentUri);
        return BitmapFactory.decodeStream(imageStream);
    }

    public static String getEncodedImage(Bitmap bm) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        byte[] b = stream.toByteArray();
        return Base64.encodeToString(b, Base64.DEFAULT);
    }

    public static String getMimeType(Context context, Uri uri) {
        String mimeType;
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
            ContentResolver cr = context.getContentResolver();
            mimeType = cr.getType(uri);
        } else {
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri
                    .toString());
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileExtension.toLowerCase());
        }
        return mimeType;
    }

    public static MultipartBody.Part createImageRequestBody(File file, String mediaType) {
        RequestBody body = RequestBody.create(MediaType.parse(mediaType), file);
        return MultipartBody.Part.createFormData("file", file.getName(), body);
    }

    public static String getMediaType(Context context, Uri tempPhotoUri) {
        return context.getContentResolver().getType(tempPhotoUri);
    }

    /**
     * A helper method for prevent errors by giving files their real type.
     * For example rename 'image.jpg' to 'image.jpeg'
     *
     * @return correct image name that would be used in api call.
     */
    public static String getCorrectImageName(String oldImageName, String mimeType) {
        String correctImageName;
        if (oldImageName.contains(".")) {
            // 'name.jpg' to 'name'
            correctImageName = oldImageName.substring(0, oldImageName.lastIndexOf("."));
        } else {
            correctImageName = oldImageName;
        }
        // 'image/jpeg' to 'jpeg'
        String type = mimeType.substring(mimeType.lastIndexOf("/") + 1, mimeType.length());
        // 'name' to 'name.jpeg'
        correctImageName = correctImageName + "." + type;
        return correctImageName;
    }

    public static String getEncodedPhotoData(String mimeType, String encodedImage) {
        return "data:" + mimeType + ";base64," + encodedImage;
    }

    public static Bitmap scaleBitmap(Context context, Bitmap source, int heightDp) {
        float aspectRatio = source.getWidth() /
                (float) source.getHeight();

        int height = Math.round(ViewUtil.dpToPixel(context, heightDp));
        int width = Math.round(height * aspectRatio);

        return Bitmap.createScaledBitmap(source, width, height, false);
    }

    public static String getUserPhotoPath(String photoSize, String photoId) {
        return addSlashToPath(UrlList.getUsersApiImage()) + getPathWithPhotoSize(photoSize, photoId);
    }

    public static String addSlashToPath(String path) {
        if (path.endsWith("/")) {
            return path;
        } else {
            return path + "/";
        }
    }

    private static String getPathWithPhotoSize(String photoSize, String photoId) {
        if (photoSize.isEmpty()) {
            return photoId;
        } else {
            return photoSize + "/" + photoId;
        }
    }

    public static void displayAvatarRound(Context context, ImageView view,
                                          String imageLink, @DrawableRes int defaultImage) {
        Glide.with(context)
                .load(ImageUtil.getUserPhotoPath(PhotoSize.MIDDLE, imageLink))
                .apply(RequestOptions.circleCropTransform())
                .apply(RequestOptions.placeholderOf(defaultImage))
                .apply(RequestOptions.errorOf(defaultImage))
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.ALL))
                .into(view);
    }

    public static void displayBusinessImageTransform(Context context, ImageView view,
                                                     String imageLink, @DrawableRes int defaultImage,
                                                     @DrawableRes int mask) {
        Glide.with(context)
                .load(imageLink)
                .apply(RequestOptions.bitmapTransform(new MultiTransformation<>(new CenterCrop(),
                        new MaskTransformation(mask))))
                .apply(RequestOptions.placeholderOf(defaultImage))
                .apply(RequestOptions.errorOf(defaultImage))
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.ALL))
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(view);
    }

    public static void displayStaffImageRound(Context context, ImageView view,
                                              String imageLink, @DrawableRes Integer defaultImage) {
        Glide.with(context)
                .load(imageLink)
                .apply(RequestOptions.circleCropTransform())
                .apply(RequestOptions.placeholderOf(defaultImage))
                .apply(RequestOptions.errorOf(defaultImage))
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.ALL))
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(view);
    }

    public static void displayStaticMap(Context context, ImageView view, String lat, String lng) {
        double centerLng = Double.valueOf(lng);
        centerLng = centerLng - 0.007; // for move map center to the right side

        String link = "https://maps.googleapis.com/maps/api/staticmap?center="
                + lat + "," + (String.valueOf(centerLng))
                + "&zoom=15&size=1280x355&markers=color:red|"
                + lat + "," + lng
                + "&scale=2";
        Glide.with(context)
                .load(link)
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.ALL))
                .into(view);
    }

    public static Bitmap bitmapFromResId(Context context, int id) {
        return BitmapFactory.decodeResource(context.getResources(), id);
    }
}
