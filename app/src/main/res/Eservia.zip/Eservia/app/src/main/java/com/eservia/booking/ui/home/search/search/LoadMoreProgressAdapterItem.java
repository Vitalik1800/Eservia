package com.eservia.booking.ui.home.search.search;

public class LoadMoreProgressAdapterItem extends SearchListItem {

    @Override
    public int getType() {
        return ITEM_LOAD_MORE_PROGRESS;
    }
}
