package com.eservia.booking.ui.booking.dialog;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.eservia.booking.R;
import com.eservia.booking.common.view.BaseDialogFragment;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class AlreadyBookedDialog extends BaseDialogFragment {

    public static AlreadyBookedDialog newInstance() {
        AlreadyBookedDialog f = new AlreadyBookedDialog();
        Bundle args = new Bundle();
        f.setArguments(args);
        return f;
    }

    @BindView(R.id.tvDialogLabel)
    TextView tvDialogLabel;
    @BindView(R.id.tvDialogMessage)
    TextView tvDialogMessage;
    @BindView(R.id.btnLeft)
    Button btnLeft;
    @BindView(R.id.btnRight)
    Button btnRight;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dialog_two_buttons, null);
        this.getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        this.getDialog().getWindow().getDecorView().setBackgroundResource(R.color.transparent);
        setUnbinder(ButterKnife.bind(this, view));
        initViews();
        return view;
    }

    @OnClick(R.id.btnLeft)
    public void onClickButtonLeft() {
        dismiss();
    }

    @OnClick(R.id.btnRight)
    public void onClickButtonRight() {
        dismiss();
    }

    private void initViews() {
        tvDialogLabel.setText(getContext().getResources().getString(R.string.already_booked));
        tvDialogMessage.setText(getContext().getResources().getString(R.string.do_another_selection));
        btnLeft.setVisibility(View.INVISIBLE);
        btnRight.setText(getContext().getResources().getString(R.string.do_another_attempt));
    }
}
