package com.eservia.booking.ui.booking.beauty.booking;

public enum Priority {
    STAFF, DATE
}
