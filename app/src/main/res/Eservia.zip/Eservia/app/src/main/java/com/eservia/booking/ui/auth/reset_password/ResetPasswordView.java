package com.eservia.booking.ui.auth.reset_password;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

@StateStrategyType(value = SkipStrategy.class)
public interface ResetPasswordView extends LoadingView {

    void onResetSuccess();

    void onResetFailed(Throwable throwable);

    void onPasswordError(String error);

    void onPasswordConfirmError(String error);

    void onCodeError(String error);

    void close();

    void hideKeyboard();
}
