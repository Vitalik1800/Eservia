package com.eservia.booking.common.view;

/**
 * Created by Valery Kotsulym on 12/13/2017.
 */

public interface OnPaginationListener {
    void loadMore();
}
