package com.eservia.booking.ui.business_page.beauty.reviews;

public class ItemCreateReview extends ReviewsAdapterItem {

    @Override
    public int getType() {
        return ITEM_CREATE_REVIEW;
    }
}
