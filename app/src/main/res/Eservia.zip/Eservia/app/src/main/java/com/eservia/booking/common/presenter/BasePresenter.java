package com.eservia.booking.common.presenter;

import com.eservia.mvp.MvpPresenter;
import com.eservia.utils.Contract;
import com.eservia.booking.common.view.BaseView;
import com.eservia.utils.LogUtils;

import io.reactivex.ObservableTransformer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;


public class BasePresenter<T extends BaseView> extends MvpPresenter<T> {

    public static final int PART = 25;

    private CompositeDisposable mDisposable;

    public BasePresenter() {
        mDisposable = new CompositeDisposable();
    }

    public void addSubscription(Disposable d) {
        if (mDisposable == null || mDisposable.isDisposed()) {
            LogUtils.debug(Contract.LOG_TAG, "CompositeDisposable is null or destroyed");
            return;
        }
        mDisposable.add(d);
    }

    public <T extends Disposable> void unSubscribeSubscription(T t) {
        if (t != null && !t.isDisposed()) {
            t.dispose();
            t = null;
        }
    }

    @Override
    public void onDestroy() {
        if (mDisposable != null) {
            mDisposable.dispose();
        }
        super.onDestroy();
    }

    public <R> ObservableTransformer<R, R> composeBinding() {
        return obs -> obs.observeOn(AndroidSchedulers.mainThread());
    }

    public boolean paginationInProgress(Disposable paginationDisposable) {
        return paginationDisposable != null && !paginationDisposable.isDisposed();
    }

    public void cancelPagination(Disposable paginationDisposable) {
        if (paginationDisposable != null) {
            paginationDisposable.dispose();
        }
    }
}
