package com.eservia.booking.ui.business_page.beauty.contacts;

public abstract class AddressAdapterItem {

    public static final int ITEM_HEADER = 1;
    public static final int ITEM_ADDRESS = 2;

    abstract public int getType();
}
