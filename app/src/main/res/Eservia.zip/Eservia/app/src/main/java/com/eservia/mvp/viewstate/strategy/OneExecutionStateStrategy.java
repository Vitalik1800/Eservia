package com.eservia.mvp.viewstate.strategy;

import com.eservia.mvp.MvpView;
import com.eservia.mvp.viewstate.ViewCommand;

import java.util.List;

/**
 * Command will be saved in commands queue. And this command will be removed after first execution.
 *
 * Date: 24.11.2016
 * Time: 11:48
 *
 * @author Yuri Shmakov
 */

public class OneExecutionStateStrategy implements StateStrategy {
	@Override
	public <View extends MvpView> void beforeApply(List<ViewCommand<View>> currentState, ViewCommand<View> incomingCommand) {
		currentState.add(incomingCommand);
	}

	@Override
	public <View extends MvpView> void afterApply(List<ViewCommand<View>> currentState, ViewCommand<View> incomingCommand) {
		currentState.remove(incomingCommand);
	}
}
