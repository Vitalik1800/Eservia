package com.eservia.booking.util;

public class ContactUtil {
    public static final String DEFAULT_NAME = "default_name";
    public static final String DEFAULT_PHONE = "+380999999999";
    public static final String DEFAULT_EMAIL = "default@gmail.com";
    public static final String DEFAULT_SUBJECT = "default_subject";
    public static final String DEFAULT_MESSAGE = "default_message";
}
