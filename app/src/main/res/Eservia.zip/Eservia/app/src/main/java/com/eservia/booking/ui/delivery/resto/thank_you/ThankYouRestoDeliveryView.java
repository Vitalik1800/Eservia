package com.eservia.booking.ui.delivery.resto.thank_you;

import com.eservia.booking.common.view.BaseView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface ThankYouRestoDeliveryView extends BaseView {

    @StateStrategyType(value = SkipStrategy.class)
    void closeView();
}
