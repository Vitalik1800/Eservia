package com.eservia.booking.ui.dish_details;

import com.eservia.model.entity.OrderRestoNomenclature;

class DishDetailsExtra {

    OrderRestoNomenclature dish;

    DishDetailsExtra(OrderRestoNomenclature dish) {
        this.dish = dish;
    }
}
