package com.eservia.mvp;

/**
 * Date: 04.02.2016
 * Time: 14:15
 *
 * @author Yuri Shmakov
 */
public interface DefaultView extends MvpView {
}
