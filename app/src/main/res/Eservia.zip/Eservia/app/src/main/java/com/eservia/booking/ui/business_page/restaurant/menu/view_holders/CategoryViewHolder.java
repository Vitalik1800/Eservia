package com.eservia.booking.ui.business_page.restaurant.menu.view_holders;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.eservia.booking.R;
import com.eservia.booking.ui.business_page.restaurant.menu.MenuAdapter;
import com.eservia.booking.ui.business_page.restaurant.menu.adapter_items.CategoryItem;
import com.eservia.booking.util.ViewUtil;
import com.eservia.utils.StringUtil;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CategoryViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.rlCardHolder)
    RelativeLayout rlCardHolder;

    @BindView(R.id.cvContainer)
    CardView cvContainer;

    @BindView(R.id.tvGroup)
    TextView tvGroup;

    @BindView(R.id.ivIconNext)
    ImageView ivIconNext;

    private MenuAdapter.OnMenuClickListener mClickListener;

    public CategoryViewHolder(View itemView, MenuAdapter.OnMenuClickListener clickListener) {
        super(itemView);
        ButterKnife.bind(this, itemView);
        mClickListener = clickListener;
    }

    public void bindView(CategoryItem item) {
        rlCardHolder.setOnClickListener(v -> {
            if (mClickListener != null) {
                mClickListener.onCategoryClicked(item);
            }
        });
        String title = item.getCategory().getName();
        tvGroup.setText(!StringUtil.isEmpty(title) ? title : "");
        ViewUtil.setCardOutlineProvider(ivIconNext.getContext(), rlCardHolder, cvContainer);
    }
}
