package com.eservia.mvp.viewstate.strategy;

import com.eservia.mvp.MvpView;
import com.eservia.mvp.viewstate.ViewCommand;

import java.util.List;


public interface StateStrategy {

	<View extends MvpView> void beforeApply(List<ViewCommand<View>> currentState, ViewCommand<View> incomingCommand);

	<View extends MvpView> void afterApply(List<ViewCommand<View>> currentState, ViewCommand<View> incomingCommand);
}
