package com.eservia.booking.ui.business_page.beauty.contacts;

public class ItemHeader extends AddressAdapterItem {

    @Override
    public int getType() {
        return ITEM_HEADER;
    }
}
