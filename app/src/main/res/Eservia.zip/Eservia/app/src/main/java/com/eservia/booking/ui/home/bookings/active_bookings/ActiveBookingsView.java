package com.eservia.booking.ui.home.bookings.active_bookings;

import androidx.fragment.app.Fragment;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

import java.util.Map;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface ActiveBookingsView extends LoadingView {

    @StateStrategyType(value = SkipStrategy.class)
    void showArchiveBookings();

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void setFragments(Map<String, Fragment> fragments);
}
