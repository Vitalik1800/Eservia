package com.eservia.booking.ui.booking.resto.placement;

import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.eservia.booking.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class DepartmentViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.rlHolder)
    RelativeLayout rlHolder;

    @BindView(R.id.tvTitle)
    TextView tvTitle;

    private DepartmentsAdapter.OnDepartmentClickListener mClickListener;

    public DepartmentViewHolder(View itemView, DepartmentsAdapter.OnDepartmentClickListener clickListener) {
        super(itemView);
        ButterKnife.bind(this, itemView);
        mClickListener = clickListener;
    }

    public void bindView(DepartmentAdapterItem item) {
        rlHolder.setOnClickListener(v -> {
            if (mClickListener != null) {
                mClickListener.onDepartmentClicked(item, getAdapterPosition());
            }
        });

        tvTitle.setText(item.getDepartment().getName());

        switch (item.getState()) {
            case SELECTED: {
                rlHolder.setBackground(ContextCompat.getDrawable(rlHolder.getContext(),
                        R.drawable.background_common_button_red_light));
                tvTitle.setTextColor(ContextCompat.getColor(tvTitle.getContext(), R.color.white));
                rlHolder.setAlpha(1.0f);
                break;
            }
            case UNSELECTED: {
                rlHolder.setBackground(ContextCompat.getDrawable(rlHolder.getContext(),
                        R.drawable.background_common_button_resto_white_red_border));
                tvTitle.setTextColor(ContextCompat.getColor(tvTitle.getContext(), R.color.resto));
                rlHolder.setAlpha(1.0f);
                break;
            }
            case DISABLED: {
                rlHolder.setBackground(ContextCompat.getDrawable(rlHolder.getContext(),
                        R.drawable.background_common_button_resto_white_red_border));
                tvTitle.setTextColor(ContextCompat.getColor(tvTitle.getContext(), R.color.resto));
                rlHolder.setAlpha(0.5f);
                break;
            }
            default: {
                rlHolder.setBackground(ContextCompat.getDrawable(rlHolder.getContext(),
                        R.drawable.background_common_button_resto_white_red_border));
                tvTitle.setTextColor(ContextCompat.getColor(tvTitle.getContext(), R.color.resto));
                rlHolder.setAlpha(1.0f);
                break;
            }
        }
    }
}
