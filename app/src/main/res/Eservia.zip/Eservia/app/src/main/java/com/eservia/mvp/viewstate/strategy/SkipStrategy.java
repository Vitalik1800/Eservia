package com.eservia.mvp.viewstate.strategy;

import com.eservia.mvp.MvpView;
import com.eservia.mvp.viewstate.ViewCommand;

import java.util.List;

/**
 * Command will not be put in commands queue
 *
 * Date: 21-Dec-15
 * Time: 17:43
 *
 * @author Alexander Blinov
 */
public class SkipStrategy implements StateStrategy {
	@Override
	public <View extends MvpView> void beforeApply(List<ViewCommand<View>> currentState, ViewCommand<View> incomingCommand) {
		//do nothing to skip
	}

	@Override
	public <View extends MvpView> void afterApply(List<ViewCommand<View>> currentState, ViewCommand<View> incomingCommand) {
		// pass
	}
}
