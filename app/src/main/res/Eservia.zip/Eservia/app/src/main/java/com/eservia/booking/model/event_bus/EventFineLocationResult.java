package com.eservia.booking.model.event_bus;

public class EventFineLocationResult {

    public EventFineLocationResult() {
    }
}
