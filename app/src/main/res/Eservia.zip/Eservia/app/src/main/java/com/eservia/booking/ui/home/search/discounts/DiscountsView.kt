package com.eservia.booking.ui.home.search.discounts

import com.eservia.booking.common.view.LoadingView
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy
import com.eservia.mvp.viewstate.strategy.SkipStrategy
import com.eservia.mvp.viewstate.strategy.StateStrategyType

@StateStrategyType(AddToEndSingleStrategy::class)
interface DiscountsView : LoadingView {

    @StateStrategyType(SkipStrategy::class)
    fun goBack()

    @StateStrategyType(SkipStrategy::class)
    fun showDiscountDetails()
}
