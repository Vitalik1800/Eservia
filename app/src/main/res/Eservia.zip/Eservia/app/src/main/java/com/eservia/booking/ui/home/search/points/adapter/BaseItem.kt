package com.eservia.booking.ui.home.search.points.adapter

abstract class BaseItem {

    //@BaseItemTypeEnum.BaseItemTypeEnum
    abstract val type: Int
}
