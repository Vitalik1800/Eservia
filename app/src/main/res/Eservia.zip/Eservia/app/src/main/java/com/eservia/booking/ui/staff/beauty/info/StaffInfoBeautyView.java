package com.eservia.booking.ui.staff.beauty.info;

import androidx.annotation.Nullable;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.booking.ui.gallery.GalleryExtra;
import com.eservia.model.entity.BeautyStaff;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface StaffInfoBeautyView extends LoadingView {

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void onStaff(@Nullable BeautyStaff staff);

    @StateStrategyType(value = SkipStrategy.class)
    void showGalleryActivity(GalleryExtra extra);
}
