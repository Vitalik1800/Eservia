package com.eservia.booking.ui.auth.registration.dialog;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.eservia.booking.R;
import com.eservia.booking.common.view.BaseDialogFragment;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class RegistrationFailedDialog extends BaseDialogFragment {

    private static final String MESSAGE = "message";

    public static RegistrationFailedDialog newInstance(String message) {
        RegistrationFailedDialog f = new RegistrationFailedDialog();
        Bundle args = new Bundle();
        args.putString(MESSAGE, message);
        f.setArguments(args);
        return f;
    }

    private String mMessage;

    @BindView(R.id.tvDialogLabel)
    TextView tvDialogLabel;
    @BindView(R.id.tvDialogMessage)
    TextView tvDialogMessage;
    @BindView(R.id.btnLeft)
    Button btnLeft;
    @BindView(R.id.btnRight)
    Button btnRight;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dialog_two_buttons, null);
        this.getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        this.getDialog().getWindow().getDecorView().setBackgroundResource(R.color.transparent);
        setUnbinder(ButterKnife.bind(this, view));
        mMessage = getArguments().getString(MESSAGE);
        initViews();
        return view;
    }

    @OnClick(R.id.btnLeft)
    public void onClickButtonLeft() {
        dismiss();
    }

    @OnClick(R.id.btnRight)
    public void onClickButtonRight() {
        dismiss();
    }

    private void initViews() {
        tvDialogLabel.setText(getContext().getResources().getString(R.string.register_failed));
        if (mMessage == null) {
            tvDialogMessage.setText(getContext().getResources().getString(
                    R.string.wrong_login_password));
        } else {
            tvDialogMessage.setText(mMessage);
        }
        btnLeft.setVisibility(View.INVISIBLE);
        btnRight.setText(getContext().getResources().getString(R.string.ok));
    }
}
