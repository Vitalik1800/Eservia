package com.eservia.booking.ui.booking.beauty;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface BookingBeautyView extends LoadingView {

    @StateStrategyType(value = SkipStrategy.class)
    void openServiceGroups();

    @StateStrategyType(value = SkipStrategy.class)
    void openBookingFragment();

    @StateStrategyType(value = SkipStrategy.class)
    void openBasketSortFragment();
}
