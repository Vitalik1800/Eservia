package com.eservia.booking.ui.splash;

import com.eservia.booking.common.view.BaseView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface SplashView extends BaseView {

    @StateStrategyType(value = SkipStrategy.class)
    void openHomeView();

    @StateStrategyType(value = SkipStrategy.class)
    void openLoginView();

    @StateStrategyType(value = SkipStrategy.class)
    void openIntro();

    @StateStrategyType(value = SkipStrategy.class)
    void showError(String message);
}
