package com.eservia.mvp;

public enum PresenterType {

	LOCAL,

	WEAK,

	GLOBAL
}