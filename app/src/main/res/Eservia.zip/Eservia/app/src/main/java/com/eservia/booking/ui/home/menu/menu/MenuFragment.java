package com.eservia.booking.ui.home.menu.menu;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.eservia.booking.R;
import com.eservia.booking.ui.about_app.AboutAppActivity;
import com.eservia.booking.ui.contacts.ContactsActivity;
import com.eservia.booking.ui.home.BaseHomeFragment;
import com.eservia.booking.ui.home.HomeActivity;
import com.eservia.booking.ui.profile.ProfileActivity;
import com.eservia.booking.util.FragmentUtil;
import com.eservia.booking.util.ImageUtil;
import com.eservia.booking.util.ViewUtil;
import com.eservia.booking.util.WindowUtils;
import com.eservia.model.entity.PhotoSize;
import com.eservia.mvp.presenter.InjectPresenter;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MenuFragment extends BaseHomeFragment implements MenuView {

    public static final String TAG = "menu_fragment";

    @BindView(R.id.fragment_container)
    CoordinatorLayout fragmentContainer;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.rlCardHolderProfile)
    RelativeLayout rlCardHolderProfile;

    @BindView(R.id.cvContainerProfile)
    CardView cvContainerProfile;

    @BindView(R.id.rlCardHolderWriteUs)
    RelativeLayout rlCardHolderWriteUs;

    @BindView(R.id.cvContainerWriteUs)
    CardView cvContainerWriteUs;

    @BindView(R.id.rlCardHolderPrivacy)
    RelativeLayout rlCardHolderPrivacy;

    @BindView(R.id.cvContainerPrivacy)
    CardView cvContainerPrivacy;

    @BindView(R.id.rlCardHolderTerms)
    RelativeLayout rlCardHolderTerms;

    @BindView(R.id.cvContainerTerms)
    CardView cvContainerTerms;

    @BindView(R.id.rlCardHolderAboutApp)
    RelativeLayout rlCardHolderAboutApp;

    @BindView(R.id.cvContainerAboutApp)
    CardView cvContainerAboutApp;

    @BindView(R.id.ivUserImage)
    ImageView ivUserImage;

    @BindView(R.id.tvUserPhone)
    TextView tvUserPhone;

    @BindView(R.id.tvUserName)
    TextView tvUserName;

    @InjectPresenter
    MenuPresenter mPresenter;

    private HomeActivity mActivity;

    public static MenuFragment newInstance() {
        return new MenuFragment();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_menu, container, false);
        mActivity = (HomeActivity) getActivity();
        setUnbinder(ButterKnife.bind(this, view));
        initViews();
        return view;
    }

    @OnClick(R.id.rlCardHolderProfile)
    public void onProfileSettingsClicked() {
        mPresenter.onProfileSettingsClicked();
    }

    @OnClick(R.id.rlCardHolderWriteUs)
    public void onWriteToUsClicked() {
        mPresenter.onWriteToUsClicked();
    }

    @OnClick(R.id.rlCardHolderPrivacy)
    public void onPrivacyClicked() {
        mPresenter.onPrivacyClicked();
    }

    @OnClick(R.id.rlCardHolderTerms)
    public void onTermsClicked() {
        mPresenter.onTermsClicked();
    }

    @OnClick(R.id.rlCardHolderAboutApp)
    public void onAboutAppClicked() {
        mPresenter.onAboutAppClicked();
    }

    @Override
    public void refresh() {
    }

    @Override
    public void willBeDisplayed() {
        WindowUtils.setLightStatusBar(mActivity);
        FragmentUtil.startFragmentTabSelectAnimation(getActivity(), fragmentContainer);
    }

    @Override
    public void willBeHidden() {
    }

    @Override
    public void showProgress() {
    }

    @Override
    public void hideProgress() {
    }

    @Override
    public void onUserPhotoLoaded(String photoId) {
        Glide.with(mActivity)
                .load(ImageUtil.getUserPhotoPath(PhotoSize.MIDDLE, photoId))
                .apply(RequestOptions.circleCropTransform())
                .apply(RequestOptions.placeholderOf(R.drawable.user_man_big))
                .apply(RequestOptions.errorOf(R.drawable.user_man_big))
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.ALL))
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(ivUserImage);
    }

    @Override
    public void onUserNameSurnameLoaded(String nameSurname) {
        tvUserName.setText(nameSurname);
    }

    @Override
    public void onUserPhoneLoaded(String phone) {
        tvUserPhone.setText(phone);
    }

    @Override
    public void openProfileSettings() {
        ProfileActivity.start(mActivity);
    }

    @Override
    public void openWriteToUs() {
        ContactsActivity.start(mActivity);
    }

    @Override
    public void openPrivacy(String privacyUrl) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(privacyUrl));
        startActivity(Intent.createChooser(intent, ""));
    }

    @Override
    public void openTerms(String termsUrl) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(termsUrl));
        startActivity(Intent.createChooser(intent, ""));
    }

    @Override
    public void openAboutApp() {
        AboutAppActivity.start(mActivity);
    }

    private void initViews() {
//        mActivity.setSupportActionBar(toolbar);
//        mActivity.getSupportActionBar().setTitle("");
//        mActivity.getSupportActionBar().setElevation(0);

        ViewUtil.setCardOutlineProvider(mActivity, rlCardHolderProfile, cvContainerProfile);
        ViewUtil.setCardOutlineProvider(mActivity, rlCardHolderWriteUs, cvContainerWriteUs);
        ViewUtil.setCardOutlineProvider(mActivity, rlCardHolderPrivacy, cvContainerPrivacy);
        ViewUtil.setCardOutlineProvider(mActivity, rlCardHolderTerms, cvContainerTerms);
        ViewUtil.setCardOutlineProvider(mActivity, rlCardHolderAboutApp, cvContainerAboutApp);
    }
}
