package com.eservia.mvp;

import static java.lang.annotation.ElementType.TYPE;

import com.eservia.mvp.viewstate.MvpViewState;

import java.lang.annotation.Target;

@Target(value = TYPE)
public @interface InjectViewState {
	Class<? extends MvpViewState> value() default DefaultViewState.class;

	Class<? extends MvpView> view() default DefaultView.class;
}
