package com.eservia.booking.ui.business_page.restaurant.menu.view_holders;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.MultiTransformation;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.eservia.booking.R;
import com.eservia.booking.ui.business_page.restaurant.menu.MenuAdapter;
import com.eservia.booking.ui.business_page.restaurant.menu.adapter_items.DishItem;
import com.eservia.booking.util.DishUtil;
import com.eservia.booking.util.ImageUtil;
import com.eservia.booking.util.ViewUtil;
import com.eservia.model.entity.OrderRestoNomenclature;
import com.eservia.model.entity.PhotoSize;
import com.eservia.utils.StringUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import jp.wasabeef.glide.transformations.MaskTransformation;

public class DishViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.rlCardHolder)
    RelativeLayout rlCardHolder;

    @BindView(R.id.cvContainer)
    CardView cvContainer;

    @BindView(R.id.ivPicture)
    ImageView ivPicture;

    @BindView(R.id.tvWeight)
    TextView tvWeight;

    @BindView(R.id.tvTime)
    TextView tvTime;

    @BindView(R.id.tvPrice)
    TextView tvPrice;

    @BindView(R.id.tvTitle)
    TextView tvTitle;

    @BindView(R.id.tvSubtitle)
    TextView tvSubtitle;

    private MenuAdapter.OnMenuClickListener mClickListener;

    public DishViewHolder(View itemView, MenuAdapter.OnMenuClickListener clickListener) {
        super(itemView);
        ButterKnife.bind(this, itemView);
        mClickListener = clickListener;
    }

    public void bindView(DishItem item) {
        rlCardHolder.setOnClickListener(v -> {
            if (mClickListener != null) {
                mClickListener.onDishClicked(item);
            }
        });

        OrderRestoNomenclature dish = item.getNomenclature();

        Glide.with(ivPicture.getContext())
                .load(ImageUtil.getUserPhotoPath(PhotoSize.MIDDLE, dish.getPhotoPath()))
                .apply(RequestOptions.bitmapTransform(new MultiTransformation<>(new CenterCrop(),
                        new MaskTransformation(R.drawable.mask_business_image))))
                .apply(RequestOptions.placeholderOf(R.drawable.icon_business_photo_placeholder_beauty))
                .apply(RequestOptions.errorOf(R.drawable.icon_business_photo_placeholder_beauty))
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.ALL))
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(ivPicture);

        tvWeight.setText(DishUtil.INSTANCE.getFormattedMinWeight(dish));

        tvTime.setText(DishUtil.INSTANCE.getFormattedCookingTime(tvTime.getContext(), dish));

        tvPrice.setText(DishUtil.INSTANCE.getFormattedMinPrice(tvPrice.getContext(), dish));

        tvTitle.setText(dish.getName());

        String description = dish.getDescription();
        tvSubtitle.setText(!StringUtil.isEmpty(description) ? description : "");
        tvSubtitle.setVisibility(!StringUtil.isEmpty(description) ? View.VISIBLE : View.GONE);

        ViewUtil.setCardOutlineProvider(rlCardHolder.getContext(), rlCardHolder, cvContainer);
    }
}
