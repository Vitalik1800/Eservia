package com.eservia.booking.ui.home.bookings.delivery_info;

import com.eservia.model.entity.RestoDelivery;

public class DeliveryInfoExtra {

    RestoDelivery delivery;

    DeliveryInfoExtra(RestoDelivery delivery) {
        this.delivery = delivery;
    }
}
