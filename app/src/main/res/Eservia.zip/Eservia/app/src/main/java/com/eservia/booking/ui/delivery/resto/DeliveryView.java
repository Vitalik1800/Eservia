package com.eservia.booking.ui.delivery.resto;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface DeliveryView extends LoadingView {

    @StateStrategyType(value = SkipStrategy.class)
    void openBasketFragment();
}
