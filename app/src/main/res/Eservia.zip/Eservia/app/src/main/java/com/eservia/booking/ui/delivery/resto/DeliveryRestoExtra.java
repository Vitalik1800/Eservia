package com.eservia.booking.ui.delivery.resto;

import com.eservia.model.entity.Business;

public class DeliveryRestoExtra {

    Business business;

    DeliveryRestoExtra(Business business) {
        this.business = business;
    }
}
