package com.eservia.booking.common.view;


import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;


public interface LoadingView extends BaseView {

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void showProgress();

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void hideProgress();
}
