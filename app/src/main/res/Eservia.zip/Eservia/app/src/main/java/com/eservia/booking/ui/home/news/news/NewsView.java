package com.eservia.booking.ui.home.news.news;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface NewsView extends LoadingView {
}
