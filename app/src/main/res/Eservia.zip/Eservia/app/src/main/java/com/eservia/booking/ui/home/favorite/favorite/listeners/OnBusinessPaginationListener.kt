package com.eservia.booking.ui.home.favorite.favorite.listeners

interface OnBusinessPaginationListener {

    fun loadMoreFavorites()
}
