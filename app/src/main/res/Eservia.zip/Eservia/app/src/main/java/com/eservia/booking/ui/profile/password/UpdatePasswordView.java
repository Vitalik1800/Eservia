package com.eservia.booking.ui.profile.password;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface UpdatePasswordView extends LoadingView {

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void onPasswordUpdated();

    @StateStrategyType(value = SkipStrategy.class)
    void onPasswordUpdateFailed(Throwable throwable);

    @StateStrategyType(value = SkipStrategy.class)
    void closeActivity();
}
