package com.eservia.booking.ui.business_page.beauty.reviews;

public abstract class ReviewsAdapterItem {

    public static final int ITEM_CREATE_REVIEW = 1;
    public static final int ITEM_REVIEW = 2;

    abstract public int getType();
}
