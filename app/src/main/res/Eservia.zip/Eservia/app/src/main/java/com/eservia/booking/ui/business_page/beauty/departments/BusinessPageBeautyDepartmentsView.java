package com.eservia.booking.ui.business_page.beauty.departments;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.model.entity.Address;
import com.eservia.model.entity.Business;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

import java.util.List;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface BusinessPageBeautyDepartmentsView extends LoadingView {

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void onAddressesLoadingSuccess(List<Address> addressList);

    @StateStrategyType(value = SkipStrategy.class)
    void onAddressesLoadingFailed(Throwable throwable);

    @StateStrategyType(value = SkipStrategy.class)
    void openBooking(Business business, Address address);
}
