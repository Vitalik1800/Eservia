package com.eservia.mvp;

import static java.lang.annotation.ElementType.TYPE;

import java.lang.annotation.Target;

/**
 * Register MoxyReflector packages from other modules
 */
@Target(value = TYPE)
public @interface RegisterMoxyReflectorPackages {
	String[] value();
}
