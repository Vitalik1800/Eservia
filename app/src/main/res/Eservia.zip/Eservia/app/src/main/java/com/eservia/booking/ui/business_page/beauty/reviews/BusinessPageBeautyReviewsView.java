package com.eservia.booking.ui.business_page.beauty.reviews;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.model.entity.Business;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

import java.util.List;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface BusinessPageBeautyReviewsView extends LoadingView {

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void onCommentsLoadingSuccess(List<ReviewsAdapterItem> comments);

    @StateStrategyType(value = SkipStrategy.class)
    void onCommentsLoadingFailed(Throwable throwable);

    @StateStrategyType(value = SkipStrategy.class)
    void openBeautyFeedback(Business business);
}
