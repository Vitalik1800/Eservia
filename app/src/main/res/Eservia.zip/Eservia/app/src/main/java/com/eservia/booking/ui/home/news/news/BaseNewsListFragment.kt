package com.eservia.booking.ui.home.news.news

import com.eservia.booking.ui.home.BaseHomeFragment

abstract class BaseNewsListFragment : BaseHomeFragment() {

    abstract fun onFilterClick()
}
