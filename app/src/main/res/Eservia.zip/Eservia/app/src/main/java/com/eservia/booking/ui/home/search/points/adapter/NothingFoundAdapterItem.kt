package com.eservia.booking.ui.home.search.points.adapter

class NothingFoundAdapterItem : BaseItem() {
    override val type: Int
        get() = BaseItemTypeEnum.NOTHING_FOUND
}