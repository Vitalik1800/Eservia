package com.eservia.booking.util;

public class ObjectTypeUtil {

    private static final String BUSINESS = "business";

    public static String business() {
        return BUSINESS;
    }
}
