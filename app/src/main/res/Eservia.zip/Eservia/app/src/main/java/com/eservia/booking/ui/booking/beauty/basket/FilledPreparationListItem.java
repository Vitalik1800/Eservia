package com.eservia.booking.ui.booking.beauty.basket;

public abstract class FilledPreparationListItem {

    public static final int TYPE_PREPARATION = 0;
    public static final int TYPE_HEADER = -1;

    public abstract int getItemType();
}
