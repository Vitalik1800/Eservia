package com.eservia.booking.ui.splash.intro;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.viewpager.widget.PagerAdapter;

import com.eservia.booking.R;

import java.util.ArrayList;
import java.util.List;

public class IntroPagerAdapter extends PagerAdapter {

    public interface OnCloseListener {
        void onCloseClicked();
    }

    private Context mContext;

    private OnCloseListener mListener;

    private List<IntroAdapterItem> mItems;

    private LayoutInflater mInflater;

    public IntroPagerAdapter(Context context, OnCloseListener listener) {
        mItems = new ArrayList<>();
        mContext = context;
        mListener = listener;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return mItems.size();
    }

    @Override
    public Object instantiateItem(ViewGroup view, int position) {
        IntroAdapterItem item = mItems.get(position);
        View imageLayout = mInflater.inflate(R.layout.item_intro_slide, view, false);

        ImageView imageView = imageLayout.findViewById(R.id.ivImage);
        TextView message = imageLayout.findViewById(R.id.tvMessage);

        if (item.getImage() != null) {
            imageView.setImageDrawable(item.getImage());
        }
        if (item.getMessage() != null) {
            message.setText(item.getMessage());
        }

        view.addView(imageLayout, 0);
        return imageLayout;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }

    public void addItems(List<IntroAdapterItem> items) {
        if (items == null) return;
        mItems.addAll(items);
        notifyDataSetChanged();
    }

    public void replaceItems(List<IntroAdapterItem> items) {
        if (items == null) return;
        mItems = items;
        notifyDataSetChanged();
    }

    public List<IntroAdapterItem> getItems() {
        return mItems;
    }
}
