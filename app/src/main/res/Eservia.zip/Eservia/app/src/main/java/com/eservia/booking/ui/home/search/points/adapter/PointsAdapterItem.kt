package com.eservia.booking.ui.home.search.points.adapter

class PointsAdapterItem : BaseItem() {
    override val type: Int
        get() = BaseItemTypeEnum.POINTS
}
