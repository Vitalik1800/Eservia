package com.eservia.booking.ui.contacts;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface ContactsView extends LoadingView {

    @StateStrategyType(value = SkipStrategy.class)
    void onFeedbackSendSuccess();

    @StateStrategyType(value = SkipStrategy.class)
    void onFeedbackSendFailed(Throwable throwable);

    @StateStrategyType(value = SkipStrategy.class)
    void closeActivity();
}
