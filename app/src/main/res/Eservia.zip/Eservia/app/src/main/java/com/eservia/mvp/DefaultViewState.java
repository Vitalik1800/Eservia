package com.eservia.mvp;

import com.eservia.mvp.viewstate.MvpViewState;

/**
 * Date: 19.12.2015
 * Time: 14:54
 *
 * @author Yuri Shmakov
 */
public final class DefaultViewState extends MvpViewState<MvpView> {
}
