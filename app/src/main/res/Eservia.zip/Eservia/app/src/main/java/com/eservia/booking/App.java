package com.eservia.booking;

import android.content.Context;
import android.content.res.Configuration;

import androidx.multidex.MultiDexApplication;

import com.eservia.booking.di.AppComponent;
import com.eservia.booking.di.DaggerManager;
import com.eservia.model.prefs.common.PreferencesManager;
import com.eservia.utils.LocaleUtil;
import com.github.piasy.biv.BigImageViewer;
import com.github.piasy.biv.loader.glide.GlideImageLoader;

public class App extends MultiDexApplication {

    public static App appInstance;
    private DaggerManager mDaggerManager;

    public static App getInstance() {
        return appInstance;
    }

    public static AppComponent getAppComponent() {
        return appInstance
                .getDaggerManager()
                .getAppComponent();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        appInstance = this;
        mDaggerManager = new DaggerManager();
        mDaggerManager.initNewAppComponent(this);
        PreferencesManager.initializeInstance(this);
        BigImageViewer.initialize(GlideImageLoader.with(this));
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleUtil.setLocale(base));
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        LocaleUtil.setLocale(this);
    }

    public DaggerManager getDaggerManager() {
        return mDaggerManager;
    }
}
