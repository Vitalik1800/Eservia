package com.eservia.booking.common.view;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.res.ResourcesCompat;

import com.eservia.booking.R;
import com.example.numberpicker.NumberPicker;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class CommonNumberPickerDialog extends BaseDialogFragment {

    private static final String TITLE = "title";
    private static final String MESSAGE = "message";

    public interface CommonNumberPickerDialogListener {
        void onValuePicked(int value);
    }

    public static CommonNumberPickerDialog newInstance(String title, String message) {
        CommonNumberPickerDialog f = new CommonNumberPickerDialog();
        Bundle args = new Bundle();
        args.putString(TITLE, title);
        args.putString(MESSAGE, message);
        f.setArguments(args);
        return f;
    }

    @BindView(R.id.tvDialogLabel)
    TextView tvDialogLabel;

    @BindView(R.id.tvDialogMessage)
    TextView tvDialogMessage;

    @BindView(R.id.btnLeft)
    Button btnLeft;

    @BindView(R.id.btnRight)
    Button btnRight;

    @BindView(R.id.npPicker)
    NumberPicker npPicker;

    @Nullable
    private CommonNumberPickerDialogListener mListener;

    @Nullable
    private NumberPicker.Formatter mFormatter;

    private int mMinValue;

    private int mMaxValue;

    private int mValue;

    @Nullable
    private String mTitle;

    @Nullable
    private String mMessage;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dialog_number_picker, null);
        this.getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        this.getDialog().getWindow().getDecorView().setBackgroundResource(R.color.transparent);
        setUnbinder(ButterKnife.bind(this, view));
        if (getArguments() != null) {
            mTitle = getArguments().getString(TITLE);
            mMessage = getArguments().getString(MESSAGE);
        }
        initViews();
        return view;
    }

    @OnClick(R.id.btnLeft)
    public void onClickButtonLeft() {
        dismiss();
    }

    @OnClick(R.id.btnRight)
    public void onClickButtonRight() {
        if (mListener != null) {
            mListener.onValuePicked(npPicker.getValue());
        }
        dismiss();
    }

    public void setListener(CommonNumberPickerDialogListener listener) {
        mListener = listener;
    }

    public void setPickerFormatter(NumberPicker.Formatter formatter) {
        mFormatter = formatter;
    }

    public void setMinMaxValue(int min, int max) {
        mMinValue = min;
        mMaxValue = max;
    }

    public void setSelectedItemAtPosition(int position) {
        mValue = position;
    }

    private void initViews() {
        if (mTitle != null) {
            tvDialogLabel.setText(mTitle);
            tvDialogLabel.setVisibility(View.VISIBLE);
        } else {
            tvDialogLabel.setVisibility(View.GONE);
        }

        if (mMessage != null) {
            tvDialogMessage.setText(mMessage);
            tvDialogMessage.setVisibility(View.VISIBLE);
        } else {
            tvDialogMessage.setVisibility(View.GONE);
        }

        btnLeft.setText(getContext().getResources().getString(R.string.cancel));
        btnRight.setText(getContext().getResources().getString(R.string.ok));

        Typeface typeface = ResourcesCompat.getFont(getContext(), R.font.roboto_medium);
        npPicker.setTypeface(typeface);

        npPicker.setMinValue(mMinValue);
        npPicker.setMaxValue(mMaxValue);

        npPicker.setFormatter(mFormatter);

        npPicker.setValue(mValue);
    }
}
