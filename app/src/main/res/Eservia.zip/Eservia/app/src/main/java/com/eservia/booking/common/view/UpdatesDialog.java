package com.eservia.booking.common.view;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.eservia.booking.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class UpdatesDialog extends BaseDialogFragment {

    public static UpdatesDialog newInstance() {
        UpdatesDialog f = new UpdatesDialog();
        Bundle args = new Bundle();
        f.setArguments(args);
        return f;
    }

    public interface UpdatesDialogListener {
        void onCancelUpdateClick();
        void onAcceptUpdateClick();
    }

    @BindView(R.id.tvDialogLabel)
    TextView tvDialogLabel;
    @BindView(R.id.tvDialogMessage)
    TextView tvDialogMessage;
    @BindView(R.id.btnLeft)
    Button btnLeft;
    @BindView(R.id.btnRight)
    Button btnRight;

    @Nullable
    private UpdatesDialogListener mListener;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dialog_two_buttons, null);
        this.getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        this.getDialog().getWindow().getDecorView().setBackgroundResource(R.color.transparent);
        setUnbinder(ButterKnife.bind(this, view));
        initViews();
        return view;
    }

    @OnClick(R.id.btnLeft)
    public void onClickButtonLeft() {
        dismiss();
        if (mListener != null) {
            mListener.onCancelUpdateClick();
        }
    }

    @OnClick(R.id.btnRight)
    public void onClickButtonRight() {
        dismiss();
        if (mListener != null) {
            mListener.onAcceptUpdateClick();
        }
    }

    public void setListener(UpdatesDialogListener listener) {
        mListener = listener;
    }

    private void initViews() {
        String appName = getContext().getResources().getString(R.string.app_name);
        tvDialogLabel.setText(getContext().getResources().getString(R.string.updates_dialog_title));
        tvDialogMessage.setText(getContext().getResources().getString(R.string.updates_dialog_message, appName));
        btnLeft.setVisibility(View.INVISIBLE);
        btnRight.setText(getContext().getResources().getString(R.string.updates_dialog_btn_update, appName));
    }
}
