package com.eservia.booking.ui.home.favorite.favorite;

import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;
import com.eservia.booking.common.view.LoadingView;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface FavoriteView extends LoadingView {

    @StateStrategyType(value = SkipStrategy.class)
    void showBusinessSuggestion();
}
