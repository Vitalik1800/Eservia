package com.eservia.booking.ui.home.search.sector;

public class NotFoundSectorsItem extends ListItem {

    @Override
    public int getType() {
        return TYPE_NOT_FOUND;
    }
}
