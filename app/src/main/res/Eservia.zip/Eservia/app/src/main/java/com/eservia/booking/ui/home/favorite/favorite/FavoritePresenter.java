package com.eservia.booking.ui.home.favorite.favorite;

import android.content.Context;

import com.eservia.mvp.InjectViewState;
import com.eservia.booking.App;
import com.eservia.booking.common.presenter.BasePresenter;
import com.eservia.model.remote.rest.RestManager;
import com.eservia.booking.util.AnalyticsHelper;

import javax.inject.Inject;

@InjectViewState
public class FavoritePresenter extends BasePresenter<FavoriteView> {

    @Inject
    RestManager mRestManager;

    @Inject
    Context mContext;

    public FavoritePresenter() {
        App.getAppComponent().inject(this);
    }

    @Override
    protected void onFirstViewAttach() {
        super.onFirstViewAttach();
    }

    public void onSuggestClicked() {
        AnalyticsHelper.logAddSalonButton(mContext);
        getViewState().showBusinessSuggestion();
    }
}
