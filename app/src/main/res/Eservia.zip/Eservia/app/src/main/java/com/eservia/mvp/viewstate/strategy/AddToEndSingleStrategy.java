package com.eservia.mvp.viewstate.strategy;


import com.eservia.mvp.MvpView;
import com.eservia.mvp.viewstate.ViewCommand;

import java.util.Iterator;
import java.util.List;

public class AddToEndSingleStrategy implements StateStrategy {
	@Override
	public <View extends MvpView> void beforeApply(List<ViewCommand<View>> currentState, ViewCommand<View> incomingCommand) {
		Iterator<ViewCommand<View>> iterator = currentState.iterator();

		while (iterator.hasNext()) {
			ViewCommand<View> entry = iterator.next();

			if (entry.getClass() == incomingCommand.getClass()) {
				iterator.remove();
				break;
			}
		}

		currentState.add(incomingCommand);
	}

	@Override
	public <View extends MvpView> void afterApply(List<ViewCommand<View>> currentState, ViewCommand<View> incomingCommand) {
		// pass
	}
}
