package com.eservia.booking.ui.suggest_business.thank_you;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.eservia.booking.R;
import com.eservia.booking.common.view.BaseActivity;
import com.eservia.booking.ui.home.BaseHomeFragment;
import com.eservia.booking.util.WindowUtils;
import com.eservia.mvp.presenter.InjectPresenter;
import com.eservia.utils.KeyboardUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SuggestBusinessThankYouFragment extends BaseHomeFragment implements SuggestBusinessThankYouView {

    public static final String TAG = "SuggestBusinessThankYouFragment";

    @BindView(R.id.fragment_container)
    CoordinatorLayout fragmentContainer;

    @InjectPresenter
    SuggestBusinessThankYouPresenter mPresenter;

    private BaseActivity mActivity;

    public static SuggestBusinessThankYouFragment newInstance() {
        return new SuggestBusinessThankYouFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_suggest_business_thank_you, container, false);
        mActivity = (BaseActivity) getActivity();
        WindowUtils.setWhiteStatusBar(mActivity);
        setUnbinder(ButterKnife.bind(this, view));
        initViews();
        return view;
    }

    @Override
    public void refresh() {
    }

    @Override
    public void willBeDisplayed() {
        WindowUtils.setWhiteStatusBar(mActivity);
    }

    @Override
    public void willBeHidden() {
    }

    @OnClick(R.id.btnAccept)
    public void onAcceptClick() {
        mPresenter.onAcceptClick();
    }

    @Override
    public void showProgress() {
    }

    @Override
    public void hideProgress() {
    }

    @Override
    public void closeView() {
        KeyboardUtil.hideSoftKeyboard(mActivity);
        mActivity.onBackPressed();
    }

    private void initViews() {
    }
}
