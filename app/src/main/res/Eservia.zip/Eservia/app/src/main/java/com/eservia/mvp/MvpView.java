package com.eservia.mvp;

/**
 * Date: 21.01.2016
 * Time: 19:58
 *
 * @author Yuri Shmakov
 */
public interface MvpView {
}
