package com.eservia.booking.ui.staff.beauty;

import com.eservia.booking.App;
import com.eservia.booking.common.presenter.BasePresenter;
import com.eservia.model.entity.BeautyStaff;
import com.eservia.model.remote.rest.RestManager;
import com.eservia.mvp.InjectViewState;

import org.greenrobot.eventbus.EventBus;

import javax.inject.Inject;

@InjectViewState
public class StaffBeautyPresenter extends BasePresenter<StaffBeautyView> {

    @Inject
    RestManager mRestManager;

    private BeautyStaff mStaff;

    public StaffBeautyPresenter() {
        App.getAppComponent().inject(this);
    }

    @Override
    protected void onFirstViewAttach() {
        super.onFirstViewAttach();
        mStaff = EventBus.getDefault().getStickyEvent(BeautyStaff.class);
        getViewState().onStaff(mStaff);
    }

    void onCloseClick() {
        getViewState().closeActivity();
    }
}
