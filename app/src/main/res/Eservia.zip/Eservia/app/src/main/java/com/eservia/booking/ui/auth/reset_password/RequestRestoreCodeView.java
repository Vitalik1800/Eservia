package com.eservia.booking.ui.auth.reset_password;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

@StateStrategyType(value = SkipStrategy.class)
public interface RequestRestoreCodeView extends LoadingView {

    void onSendSuccess();

    void onSendFailed(Throwable throwable);

    void onPhoneError(String error);

    void openResetPass();

    void hideKeyboard();
}
