package com.eservia.booking.common.view;

import com.eservia.mvp.MvpView;


public interface BaseView extends MvpView {
}
