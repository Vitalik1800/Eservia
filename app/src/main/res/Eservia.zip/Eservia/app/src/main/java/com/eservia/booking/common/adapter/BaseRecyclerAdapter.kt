package com.eservia.booking.common.adapter

import androidx.recyclerview.widget.RecyclerView

abstract class BaseRecyclerAdapter<T> : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val THRESHHOLD = 25
    }

    protected var listItems: MutableList<T> = ArrayList()

    override fun getItemCount(): Int {
        return this.listItems.size
    }

    fun getItem(position: Int): T {
        return this.listItems[position]
    }

    fun getAdapterItems(): List<T> {
        return ArrayList(this.listItems)
    }

    fun addAll(items: List<T>) {
        this.listItems.addAll(items)
        notifyDataSetChanged()
    }

    fun replaceAll(items: List<T>) {
        this.listItems.clear()
        addAll(items)
    }

    fun addItem(item: T) {
        this.listItems.add(item)
        notifyDataSetChanged()
    }

    fun remove(item: T) {
        this.listItems.remove(item)
        notifyDataSetChanged()
    }

    fun remove(id: Int) {
        this.listItems.removeAt(id)
        notifyDataSetChanged()
    }

    fun clearAll() {
        this.listItems.clear()
        notifyDataSetChanged()
    }
}
