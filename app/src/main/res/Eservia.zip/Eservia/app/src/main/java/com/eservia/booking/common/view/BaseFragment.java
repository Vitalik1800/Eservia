package com.eservia.booking.common.view;


import androidx.annotation.CallSuper;
import androidx.annotation.Nullable;

import com.eservia.mvp.MvpAppCompatFragment;

import butterknife.Unbinder;

public class BaseFragment extends MvpAppCompatFragment {

    @Nullable
    private Unbinder mUnbinder;

    public void setUnbinder(Unbinder unbinder) {
        mUnbinder = unbinder;
    }

    @CallSuper
    @Override
    public void onDestroyView() {
        if (mUnbinder != null) {
            mUnbinder.unbind();
            mUnbinder = null;
        }
        super.onDestroyView();
    }
}
