package com.eservia.booking.ui.business_page.beauty.contacts;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

import java.util.List;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface BusinessPageBeautyContactsView extends LoadingView {

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void onAddressesLoadingSuccess(List<AddressAdapterItem> adapterItems);

    @StateStrategyType(value = SkipStrategy.class)
    void onAddressesLoadingFailed(Throwable throwable);

    @StateStrategyType(value = SkipStrategy.class)
    void openMap(String title, Double lat, Double lng);

    @StateStrategyType(value = SkipStrategy.class)
    void openPhone(String number);
}
