package com.eservia.booking.ui.home.bookings.archive_bookings;

import com.eservia.booking.App;
import com.eservia.booking.common.presenter.BasePresenter;
import com.eservia.model.remote.rest.RestManager;
import com.eservia.mvp.InjectViewState;

import javax.inject.Inject;

@InjectViewState
public class ArchiveBookingsPresenter extends BasePresenter<ArchiveBookingsView> {

    @Inject
    RestManager mRestManager;

    public ArchiveBookingsPresenter() {
        App.getAppComponent().inject(this);
    }

    @Override
    protected void onFirstViewAttach() {
        super.onFirstViewAttach();
    }
}
