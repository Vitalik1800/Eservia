package com.eservia.booking.ui.home.bookings.archive_bookings.general_archive_bookings

import com.eservia.booking.common.view.LoadingView
import com.eservia.model.entity.RestoDelivery
import com.eservia.model.remote.rest.booking_resto.services.general_booking.GeneralBookingsResponseData
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy
import com.eservia.mvp.viewstate.strategy.SkipStrategy
import com.eservia.mvp.viewstate.strategy.StateStrategyType

@StateStrategyType(value = AddToEndSingleStrategy::class)
interface GeneralArchiveBookingsView : LoadingView {

    @StateStrategyType(value = AddToEndSingleStrategy::class)
    fun onBookingsLoadingSuccess(bookings: List<GeneralBookingsResponseData>)

    @StateStrategyType(value = SkipStrategy::class)
    fun onBookingsLoadingFailed(throwable: Throwable)

    @StateStrategyType(value = SkipStrategy::class)
    fun openDeliveryDetails(delivery: RestoDelivery)
}
