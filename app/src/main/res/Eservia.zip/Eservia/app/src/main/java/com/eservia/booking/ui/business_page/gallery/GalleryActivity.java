package com.eservia.booking.ui.business_page.gallery;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.viewpager.widget.ViewPager;

import com.eservia.booking.R;
import com.eservia.booking.common.view.BaseActivity;
import com.eservia.model.entity.BusinessPhoto;
import com.eservia.mvp.presenter.InjectPresenter;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class GalleryActivity extends BaseActivity implements GalleryView {

    @BindView(R.id.pager)
    ViewPager pager;

    @BindView(R.id.rlHeader)
    RelativeLayout rlHeader;

    @BindView(R.id.ibClose)
    ImageButton ibClose;

    @BindView(R.id.rlBottomNavigation)
    RelativeLayout rlBottomNavigation;

    @BindView(R.id.tvPageNumber)
    TextView tvPageNumber;

    @BindView(R.id.rlPrevPage)
    RelativeLayout rlPrevPage;

    @BindView(R.id.rlNextPage)
    RelativeLayout rlNextPage;

    @BindView(R.id.ivPrev)
    ImageView ivPrev;

    @BindView(R.id.ivNext)
    ImageView ivNext;

    @InjectPresenter
    GalleryPresenter mPresenter;

    private Handler mHandler;

    private GalleryAdapter mAdapter;

    private int mCurrentPage = 0;

    private boolean isControlsHidden = false;

    public static void start(Context context, BusinessGalleryExtra extra) {
        EventBus.getDefault().postSticky(extra);
        Intent starter = new Intent(context, GalleryActivity.class);
        context.startActivity(starter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_gallery);
        setUnbinder(ButterKnife.bind(this));
        initViews();
    }

    @OnClick(R.id.ibClose)
    public void onCloseClick() {
        finish();
    }

    @OnClick(R.id.rlPrevPage)
    public void onLeftClick() {
        mHandler.post(showPrevPage);
    }

    @OnClick(R.id.rlNextPage)
    public void onRightClick() {
        mHandler.post(showNextPage);
    }

    @Override
    public void showProgress() {
    }

    @Override
    public void hideProgress() {
    }

    @Override
    public void onStartPosition(int startPosition) {
        mCurrentPage = startPosition;
    }

    @Override
    public void initWith(List<BusinessPhoto> businessPhotos) {
        mAdapter.replacePhotos(businessPhotos);
        setCurrentPage();
    }

    @Override
    public void onPhotosLoadingSuccess(List<BusinessPhoto> businessPhotos) {
        mAdapter.replacePhotos(businessPhotos);
    }

    @Override
    public void onPhotosLoadingFailed(Throwable throwable) {
    }

    @Override
    public void toggleControls() {
        if (!isControlsHidden) {
            hideHeaderBar();
            hideBottomBar();
            isControlsHidden = true;
        } else {
            showHeaderBar();
            showBottomBar();
            isControlsHidden = false;
        }
    }

    private void hideHeaderBar() {
        rlHeader.animate().translationY(0.0f - rlHeader.getHeight());
    }

    private void showHeaderBar() {
        rlHeader.animate().translationY(0);
    }

    private void hideBottomBar() {
        rlBottomNavigation.animate().translationY(rlBottomNavigation.getHeight());
    }

    private void showBottomBar() {
        rlBottomNavigation.animate().translationY(0);
    }

    private Runnable showPrevPage = () -> {
        if (mCurrentPage > 0) {
            mCurrentPage--;
        }
        setCurrentPage();
    };

    private Runnable showNextPage = () -> {
        if (mCurrentPage < mAdapter.getCount() - 1) {
            mCurrentPage++;
        }
        setCurrentPage();
    };

    private void setCurrentPage() {
        pager.setCurrentItem(mCurrentPage, true);
        refreshControls();
    }

    private void refreshControls() {
        if (mCurrentPage <= 0) {
            rlPrevPage.setAlpha(0.5f);
        } else {
            rlPrevPage.setAlpha(1.0f);
        }

        if (mCurrentPage >= mAdapter.getCount() - 1) {
            rlNextPage.setAlpha(0.5f);
        } else {
            rlNextPage.setAlpha(1.0f);
        }
    }

    private void initViews() {
        mHandler = new Handler();
        mAdapter = new GalleryAdapter(this, mPresenter, mPresenter);
        pager.setAdapter(mAdapter);
        pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                mCurrentPage = position;
                refreshControls();
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }
}
