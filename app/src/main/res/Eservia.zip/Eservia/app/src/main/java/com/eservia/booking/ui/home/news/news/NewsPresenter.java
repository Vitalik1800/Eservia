package com.eservia.booking.ui.home.news.news;

import com.eservia.booking.common.presenter.BasePresenter;
import com.eservia.mvp.InjectViewState;

@InjectViewState
public class NewsPresenter extends BasePresenter<NewsView> {

    public NewsPresenter() {
    }

    @Override
    protected void onFirstViewAttach() {
        super.onFirstViewAttach();
    }
}
