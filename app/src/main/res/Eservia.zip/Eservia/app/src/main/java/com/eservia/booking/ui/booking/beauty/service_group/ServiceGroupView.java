package com.eservia.booking.ui.booking.beauty.service_group;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.model.entity.Address;
import com.eservia.model.entity.BeautyServiceGroup;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

import java.util.List;

public interface ServiceGroupView extends LoadingView {

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void onServiceGroupsLoadingSuccess(List<BeautyServiceGroup> serviceGroupList);

    @StateStrategyType(value = SkipStrategy.class)
    void onServiceGroupsLoadingFailed(Throwable throwable);

    @StateStrategyType(value = SkipStrategy.class)
    void showServiceFragment(boolean startFromSearch);

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void showSelectedAddress(Address address);

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void refreshBasketState(int preparationsCount);
}
