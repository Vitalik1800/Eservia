package com.eservia.booking.util;


import androidx.annotation.NonNull;
import androidx.annotation.StringRes;

import com.eservia.booking.R;
import com.eservia.booking.util.parsers.ErrorUsersParser;
import com.eservia.model.remote.error.NetworkErrorCode;
import com.eservia.model.remote.rest.retrofit.RetrofitException;
import com.eservia.model.remote.rest.retrofit.ServerResponseError;
import com.eservia.model.remote.rest.users.services.UsersServerResponse;

import java.util.concurrent.TimeoutException;

public class ServerErrorUtil {

    public static int getErrorCode(@NonNull Throwable throwable) {
        int errorCode = 0;
        if (throwable instanceof RetrofitException) {
            RetrofitException e = (RetrofitException) throwable;
            errorCode = e.getCode();
        }
        return errorCode;
    }

    public static boolean isConnectionError(@NonNull Throwable throwable) {
        if (throwable instanceof RetrofitException) {
            RetrofitException e = (RetrofitException) throwable;
            if (e.getCode() == NetworkErrorCode.NO_INTERNET ||
                    e.getCode() == NetworkErrorCode.TIMEOUT) {
                return true;
            }
        } else if (throwable instanceof TimeoutException) {
            return true;
        }
        return false;
    }

    @StringRes
    public static int getErrorStringRes(@NonNull Throwable throwable) {
        if (throwable instanceof RetrofitException) {
            RetrofitException e = (RetrofitException) throwable;
            if (e.getCause() instanceof ServerResponseError) {
                ServerResponseError err = ((ServerResponseError) e.getCause());
                if (err.getResponse() instanceof UsersServerResponse){
                    return parseUsersErrorCode(e.getCode());
                }
            }
            return parseErrorCode(e.getCode());
        } else if (throwable instanceof TimeoutException) {
            return R.string.error_no_internet;
        } else {
            return R.string.error_unknown;
        }
    }

    public static String getServerErrorString(@NonNull Throwable throwable) {
//        String message = "";
//        if (throwable instanceof RetrofitException) {
//            RetrofitException e = (RetrofitException) throwable;
//            if (e.getCause() instanceof ServerResponseError) {
//                ServerResponseError err = ((ServerResponseError) e.getCause());
//                if (err.getResponse() instanceof BookingServerResponse) {
//                    message = ((BookingServerResponse) err.getResponse()).getError();
//                }
//            }
//        }
        return "";
    }

    public static String getServerFirstErrorString(@NonNull Throwable throwable) {
//        String message = "";
//        if (throwable instanceof RetrofitException) {
//            RetrofitException e = (RetrofitException) throwable;
//            if (e.getCause() instanceof ServerResponseError) {
//                ServerResponseError err = ((ServerResponseError) e.getCause());
//                if (err.getResponse() instanceof BookingServerResponse) {
//                    ResponseError[] errors = ((BookingServerResponse) err.getResponse()).getErrors();
//                    if (errors != null && errors.length > 0) {
//                        message = errors[0].getErrors()[0].getMessage();
//                    }
//                }
//            }
//        }
        return "";
    }

    @StringRes
    private static int parseErrorCode(int errorCode) {
        switch (errorCode) {
            case NetworkErrorCode.UNKNOWN:
                return R.string.unknown_error;
            case NetworkErrorCode.INVALID_RESPONSE:
                return R.string.unknown_error;
            case NetworkErrorCode.TIMEOUT:
                return R.string.timeout;
            case NetworkErrorCode.NO_INTERNET:
                return R.string.error_no_internet;
            default:
                return R.string.unknown_error;
        }
    }

/*    @StringRes
    private static int parseBookingErrorCode(int errorCode) {
        switch (errorCode) {
            case BookingServerResponseState.ERROR:
                return R.string.error_unknown;
            case BookingServerResponseState.ALREADY_BOOKED:
                return R.string.error_already_booked;
            case BookingServerResponseState.INVALID_DATA:
                return R.string.error_invalid_data;
            case BookingServerResponseState.UNAUTHORIZED:
                return R.string.error_unauthorized;
            default:
                return R.string.error_unknown;
        }
    }*/

    @StringRes
    private static int parseUsersErrorCode(int errorCode) {
        return ErrorUsersParser.parseErrorCode(errorCode);
    }
}
