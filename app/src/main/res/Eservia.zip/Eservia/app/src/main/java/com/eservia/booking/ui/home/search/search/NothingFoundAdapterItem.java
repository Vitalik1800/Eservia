package com.eservia.booking.ui.home.search.search;

public class NothingFoundAdapterItem extends SearchListItem {

    @Override
    public int getType() {
        return ITEM_NOTHING_FOUND;
    }
}
