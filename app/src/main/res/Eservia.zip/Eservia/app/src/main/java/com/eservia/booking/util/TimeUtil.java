package com.eservia.booking.util;

import android.content.Context;
import android.util.SparseArray;

import androidx.annotation.StringRes;

import com.eservia.booking.R;
import com.eservia.utils.RRuleUtil;

import org.joda.time.DateTime;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

public class TimeUtil {

    public static final long ONE_DAY = 24 * 60 * 60 * 1000L;

    private static final int DAYS_IN_MONTH = 30;
    private static final int DAYS_IN_2_MONTH = 60;
    private static final int DAYS_IN_3_MONTH = 90;
    private static final int DAYS_IN_6_MONTH = 180;

    public static boolean isSameDay(DateTime first, DateTime second) {
        return first.getYear() == second.getYear() && first.getDayOfYear() == second.getDayOfYear();
    }

    public static boolean isSameMonth(DateTime first, DateTime second) {
        return first.getYear() == second.getYear() && first.getMonthOfYear() == second.getMonthOfYear();
    }

    public static DateTime dateTimeFromMillisOfDay(Integer millisOfDay) {
        return millisOfDay != null ? DateTime.now().withMillisOfDay(millisOfDay % 86400000) : null;
    }

    public static Calendar isoToCalendar(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }

    public static Calendar increaseByOneMonth(Calendar calendar) {
        return increase(calendar, DAYS_IN_MONTH);
    }

    public static Calendar increaseByTwoMonth(Calendar calendar) {
        return increase(calendar, DAYS_IN_2_MONTH);
    }

    public static Calendar increaseByThreeMonth(Calendar calendar) {
        return increase(calendar, DAYS_IN_3_MONTH);
    }

    public static Calendar increaseBySixMonth(Calendar calendar) {
        return increase(calendar, DAYS_IN_6_MONTH);
    }

    private static Calendar increase(Calendar calendar, int increaseDays) {
        long startTime = calendar.getTimeInMillis();
        Date increasedTime = new Date(startTime + increaseDays * TimeUtil.ONE_DAY);
        return isoToCalendar(increasedTime);
    }

    public static int calendarDay(String shortWeekDay) {
        shortWeekDay = shortWeekDay.toUpperCase();
        switch (shortWeekDay) {
            case "SUN": {
                return Calendar.SUNDAY;
            }
            case "MON": {
                return Calendar.MONDAY;
            }
            case "TUE": {
                return Calendar.TUESDAY;
            }
            case "WED": {
                return Calendar.WEDNESDAY;
            }
            case "THU": {
                return Calendar.THURSDAY;
            }
            case "FRI": {
                return Calendar.FRIDAY;
            }
            case "SAT": {
                return Calendar.SATURDAY;
            }
            default:
                throw new IllegalStateException("unsupported item type");
        }
    }

    public static String weekDayName(Context context, int index) {
        switch (index) {
            case 1: {
                return getString(context, R.string.monday);
            }
            case 2: {
                return getString(context, R.string.tuesday);
            }
            case 3: {
                return getString(context, R.string.wednesday);
            }
            case 4: {
                return getString(context, R.string.thursday);
            }
            case 5: {
                return getString(context, R.string.friday);
            }
            case 6: {
                return getString(context, R.string.saturday);
            }
            case 7: {
                return getString(context, R.string.sunday);
            }
            default:
                return "";
        }
    }

    private static String getString(Context context, @StringRes int id) {
        return context.getResources().getString(id);
    }

    public static SparseArray<String> toWeekDaysAndWorkTime(List<RRuleUtil.Day> workingDays) {
        List<RRuleUtil.Day> filteredDays = generateDays(workingDays);
        SparseArray<String> workWeekDays = new SparseArray<>();
        for (RRuleUtil.Day day : filteredDays) {
            int weekDay = day.getDateTime().getDayOfWeek();
            String workTime;
            if (day.getTimeStart() != null && day.getTimeEnd() != null) {
                String startTime = day.getTimeStart().getHour() + ":" + day.getTimeStart().getMin();
                String endTime = day.getTimeEnd().getHour() + ":" + day.getTimeEnd().getMin();
                workTime = startTime + " - " + endTime;
            } else {
                workTime = "-- : --";
            }
            workWeekDays.put(weekDay, workTime);
        }
        return workWeekDays;
    }

    public static SparseArray<String> toWeekDaysAndEndTime(Context context,
                                                           List<RRuleUtil.Day> workingDays) {
        List<RRuleUtil.Day> filteredDays = generateDays(workingDays);
        SparseArray<String> workWeekDays = new SparseArray<>();
        for (RRuleUtil.Day day : filteredDays) {
            int weekDay = day.getDateTime().getDayOfWeek();
            String formattedEndTime;
            if (day.getTimeStart() != null && day.getTimeEnd() != null) {
                String endTime = day.getTimeEnd().getHour() + ":" + day.getTimeEnd().getMin();
                formattedEndTime = context.getString(R.string.until_) + " " + endTime;
            } else {
                formattedEndTime = "-- : --";
            }
            workWeekDays.put(weekDay, formattedEndTime);
        }
        return workWeekDays;
    }

    private static List<RRuleUtil.Day> generateDays(List<RRuleUtil.Day> days) {
        DateTime now = DateTime.now().minusDays(1);
        DateTime nextWeek = now.plusDays(7);
        List<RRuleUtil.Day> filteredDays = new ArrayList<>();
        for (RRuleUtil.Day day : days) {
            if (day.getDateTime().isAfter(now) && day.getDateTime().isBefore(nextWeek)) {
                filteredDays.add(day);
            }
        }
        return filteredDays;
    }

    public static String calendarToTimeSlotString(final Calendar calendar) {
        String hour = String.valueOf(calendar.get(Calendar.HOUR_OF_DAY));
        String minute = String.valueOf(calendar.get(Calendar.MINUTE));
        if (minute.equals("0")) {
            minute = minute + "0";
        }
        return hour + ":" + minute;
    }

    public static String currentTimeZoneId() {
        return TimeZone.getDefault().getID();
    }

    /**
     * Transform Calendar to ISO 8601 string.
     **/
    public static String fromCalendarToIso(final Calendar calendar) {
        Date date = calendar.getTime();
        return new SimpleDateFormat("dd-MM-yyyy").format(date);
        //String formatted = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(date);
        //return formatted.substring(0, 22) + ":" + formatted.substring(22);
    }

    /**
     * Transform Calendar to ISO 8601 string.
     **/
    public static String fromCalendarToIsoWithHour(final Calendar calendar) {
        Date date = calendar.getTime();
        String formatted = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(date);
        return formatted.substring(0, 22) + ":" + formatted.substring(22);
    }

    /**
     * Get current date and time formatted as ISO 8601 string.
     */
    public static String currentTimeIso() {
        return fromCalendarToIso(GregorianCalendar.getInstance());
    }

    /**
     * Transform ISO 8601 string to Calendar.
     */
    public static Calendar isoToCalendar(final String iso8601string)
            throws ParseException {
        Calendar calendar = GregorianCalendar.getInstance();
        String s = iso8601string.replace("Z", "+00:00");
        try {
            s = s.substring(0, 22) + s.substring(23);  // to get rid of the ":"
        } catch (IndexOutOfBoundsException e) {
            throw new ParseException("Invalid length", 0);
        }
        Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").parse(s);
        calendar.setTime(date);
        return calendar;
    }

    public static String isoToFormattedString(final String iso8601string) throws ParseException {
        Date time = isoToCalendar(iso8601string).getTime();
        DateFormat df = new SimpleDateFormat("E, dd MMM yyyy HH:mm");
        return df.format(time);
    }
}
