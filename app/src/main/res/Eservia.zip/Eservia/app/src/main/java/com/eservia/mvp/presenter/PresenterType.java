package com.eservia.mvp.presenter;

public enum PresenterType {

	LOCAL,

	WEAK,

	GLOBAL
}
