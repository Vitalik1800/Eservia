package com.eservia.mvp.presenter;

import com.eservia.mvp.MvpPresenter;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ProvidePresenterTag {
	String EMPTY = "";

	Class<? extends MvpPresenter<?>> presenterClass();

	PresenterType type() default PresenterType.LOCAL;

	String presenterId() default EMPTY;
}
