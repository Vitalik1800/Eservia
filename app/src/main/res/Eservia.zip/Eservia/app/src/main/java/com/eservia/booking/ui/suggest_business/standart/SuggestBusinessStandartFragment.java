package com.eservia.booking.ui.suggest_business.standart;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.FragmentManager;

import com.eservia.booking.R;
import com.eservia.booking.common.view.BaseActivity;
import com.eservia.booking.ui.home.BaseHomeFragment;
import com.eservia.booking.util.ColorUtil;
import com.eservia.booking.util.FragmentUtil;
import com.eservia.booking.util.MessageUtil;
import com.eservia.booking.util.ValidatorUtil;
import com.eservia.booking.util.ViewUtil;
import com.eservia.booking.util.WindowUtils;
import com.eservia.mvp.presenter.InjectPresenter;
import com.eservia.utils.KeyboardUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SuggestBusinessStandartFragment extends BaseHomeFragment implements SuggestBusinessStandartView {

    public static final String TAG = "SuggestBusinessStandartFragment";

    @BindView(R.id.fragment_container)
    CoordinatorLayout fragmentContainer;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.pbProgress)
    ProgressBar pbProgress;

    @BindView(R.id.tvToolbarSubTitle)
    TextView tvToolbarSubTitle;

    @BindView(R.id.rlAccept)
    RelativeLayout rlAccept;

    @BindView(R.id.rlCardHolderSuggestBusiness)
    RelativeLayout rlCardHolderSuggestBusiness;

    @BindView(R.id.cvContainerSuggestBusiness)
    CardView cvContainerSuggestBusiness;

    @BindView(R.id.etName)
    EditText etName;

    @BindView(R.id.etCity)
    EditText etCity;

    @BindView(R.id.etAddress)
    EditText etAddress;

    @InjectPresenter
    SuggestBusinessStandartPresenter mPresenter;

    private BaseActivity mActivity;

    public static SuggestBusinessStandartFragment newInstance() {
        SuggestBusinessStandartFragment fragment = new SuggestBusinessStandartFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_suggest_business_standart, container, false);
        mActivity = (BaseActivity) getActivity();
        WindowUtils.setLightStatusBar(mActivity);
        setUnbinder(ButterKnife.bind(this, view));
        initViews();
        return view;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                KeyboardUtil.hideSoftKeyboard(mActivity);
                mActivity.onBackPressed();
                return true;
            }
        }
        return false;
    }

    @Override
    public void refresh() {
    }

    @Override
    public void willBeDisplayed() {
        WindowUtils.setLightStatusBar(mActivity);
    }

    @Override
    public void willBeHidden() {
    }

    @OnClick(R.id.rlAccept)
    public void onAcceptClick() {
        trySend();
    }

    @Override
    public void showProgress() {
        pbProgress.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgress() {
        pbProgress.setVisibility(View.GONE);
    }

    @Override
    public void onSendSuggestionSuccess() {
    }

    @Override
    public void onSendSuggestionFailed(Throwable throwable) {
        MessageUtil.showSnackbar(fragmentContainer, throwable);
    }

    @Override
    public void showSuccess() {
        FragmentManager fragmentManager = mActivity.getSupportFragmentManager();
        FragmentUtil.popAllBackStack(fragmentManager);
        openThankYouFragment();
    }

    private void trySend() {
        KeyboardUtil.hideSoftKeyboard(mActivity);

        String name = etName.getText().toString();
        String city = etCity.getText().toString();
        String address = etAddress.getText().toString();

        etName.setError(ValidatorUtil.isTextValid(mActivity, name));
        etCity.setError(ValidatorUtil.isTextValid(mActivity, city));
        etAddress.setError(ValidatorUtil.isTextValid(mActivity, address));

        if (!hasErrors()) {
            mPresenter.onAcceptClick(name, city, address);
        }
    }

    private boolean hasErrors() {
        boolean error = false;

        if (etAddress.getError() != null) {
            etAddress.requestFocus();
            error = true;
        }

        if (etCity.getError() != null) {
            etCity.requestFocus();
            error = true;
        }

        if (etName.getError() != null) {
            etName.requestFocus();
            error = true;
        }
        return error;
    }

    private void initViews() {
        mActivity.setSupportActionBar(toolbar);
        mActivity.getSupportActionBar().setTitle("");
        mActivity.getSupportActionBar().setElevation(0);

        initSwipeRefresh();

        ViewUtil.setCardOutlineProvider(mActivity, rlCardHolderSuggestBusiness,
                cvContainerSuggestBusiness);

/*        etAddress.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                trySend();
                return true;
            }
            return false;
        });*/
    }

    private void initSwipeRefresh() {
        ColorUtil.setProgressColor(pbProgress, R.color.colorPrimary);
    }

    private void openThankYouFragment() {
        if (mActivity == null) return;
        FragmentManager fragmentManager = mActivity.getSupportFragmentManager();
        FragmentUtil.openSuggestBusinessThankYouFragment(fragmentManager, R.id.suggestBusinessContainer);
    }
}
