package com.eservia.booking.ui.home.search.sector;

public class ChooseSectorItem extends ListItem {

    @Override
    public int getType() {
        return TYPE_CHOOSE_SECTOR;
    }
}
