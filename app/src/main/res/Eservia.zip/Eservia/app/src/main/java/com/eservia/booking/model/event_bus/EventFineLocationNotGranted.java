package com.eservia.booking.model.event_bus;

public class EventFineLocationNotGranted {
}
