package com.eservia.booking.ui.suggest_business.thank_you;

import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface SuggestBusinessThankYouView extends LoadingView {

    @StateStrategyType(value = SkipStrategy.class)
    void closeView();
}
