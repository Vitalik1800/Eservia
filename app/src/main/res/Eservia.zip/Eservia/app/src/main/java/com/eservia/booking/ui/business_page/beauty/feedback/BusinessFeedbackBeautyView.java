package com.eservia.booking.ui.business_page.beauty.feedback;

import com.eservia.mvp.viewstate.strategy.SkipStrategy;
import com.eservia.booking.common.view.LoadingView;
import com.eservia.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.eservia.mvp.viewstate.strategy.StateStrategyType;

import java.util.List;

@StateStrategyType(value = AddToEndSingleStrategy.class)
public interface BusinessFeedbackBeautyView extends LoadingView {

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void initMaxMinDefault(int maxRating, int minRating, int defaultRating);

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void setQualityStars(List<StarItem> stars);

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void setPurityStars(List<StarItem> stars);

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void setConvenienceStars(List<StarItem> stars);

    @StateStrategyType(value = AddToEndSingleStrategy.class)
    void onTotalRating(float rating);

    @StateStrategyType(value = SkipStrategy.class)
    void onCreateCommentSuccess();

    @StateStrategyType(value = SkipStrategy.class)
    void onCreateCommentFailed(Throwable error);
}
