package com.eservia.booking.ui.auth.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.eservia.booking.R;
import com.eservia.booking.common.view.BaseActivity;
import com.eservia.booking.common.view.ClearFocusLayoutListener;
import com.eservia.booking.ui.auth.approve_phone.PhoneApproveActivity;
import com.eservia.booking.ui.auth.login.dialog.LoginFailedDialog;
import com.eservia.booking.ui.auth.login.facebook.FacebookLoginManager;
import com.eservia.booking.ui.auth.login.google.GoogleLoginManager;
import com.eservia.booking.ui.auth.register_phone.RegisterPhoneActivity;
import com.eservia.booking.ui.auth.registration.RegistrationActivity;
import com.eservia.booking.ui.auth.reset_password.RequestRestoreCodeActivity;
import com.eservia.booking.ui.splash.SplashActivity;
import com.eservia.booking.util.ColorUtil;
import com.eservia.booking.util.MessageUtil;
import com.eservia.booking.util.ValidatorUtil;
import com.eservia.booking.util.ViewUtil;
import com.eservia.booking.util.WindowUtils;
import com.eservia.model.entity.Provider;
import com.eservia.mvp.presenter.InjectPresenter;
import com.eservia.utils.KeyboardUtil;
import com.eservia.utils.PhoneUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class LoginActivity extends BaseActivity implements
        LoginView,
        LoginFailedDialog.OnButtonClickListener,
        FacebookLoginManager.FacebookLoginListener,
        GoogleLoginManager.GoogleLoginListener {

    @InjectPresenter
    LoginPresenter mLoginPresenter;

    @BindView(R.id.scrollView)
    ScrollView scrollView;

    @BindView(R.id.rlLoginContent)
    RelativeLayout rlLoginContent;

    @BindView(R.id.etPhone)
    EditText etPhone;

    @BindView(R.id.etPassword)
    EditText etPassword;

    @BindView(R.id.btnLogin)
    Button btnLogin;

    @BindView(R.id.ivFacebook)
    ImageView mFacebook;

    @BindView(R.id.ivGoogle)
    ImageView mGoogle;

    @BindView(R.id.pbProgress)
    ProgressBar pbProgress;

    @BindView(R.id.cbShowPassword)
    CheckBox cbShowPassword;

    private FacebookLoginManager mFacebookLoginManager;

    private GoogleLoginManager mGoogleLoginManager;

    public static void start(Context context) {
        Intent starter = new Intent(context, LoginActivity.class);
        starter.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(starter);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        WindowUtils.setLightStatusBar(this);
        setUnbinder(ButterKnife.bind(this));
        initViews();
        mFacebookLoginManager = new FacebookLoginManager();
        mGoogleLoginManager = new GoogleLoginManager(this, this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mGoogleLoginManager.dispose();
    }

    @OnClick(R.id.btnLogin)
    public void onLoginButtonClicked() {
        attemptLogin();
    }

    @OnClick(R.id.btnCreateAccount)
    public void onCreateAccountButtonClicked() {
        openRegistrationActivity();
    }

    @OnClick(R.id.ivFacebook)
    public void onFacebookLoginClick() {
        mFacebookLoginManager.signIn(this, this);
    }

    @OnClick(R.id.ivGoogle)
    public void onGoogleLoginClick() {
        mGoogleLoginManager.startGoogleLogin();
    }

    @OnClick(R.id.btnForgotPassword)
    public void onForgotPassButtonClick() {
        openRequestRestoreCodeActivity();
    }

    @Override
    public void showProgress() {
        WindowUtils.setTouchable(this, false);
        pbProgress.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgress() {
        WindowUtils.setTouchable(this, true);
        pbProgress.setVisibility(View.GONE);
    }

    @Override
    public void onLoginSuccess() {
        openSplashScreen();
    }

    @Override
    public void onLoginFailed(Throwable throwable) {
        openLoginFailedDialog(MessageUtil.getResErrorOrServerErrorMessage(this, throwable));
    }

    @Override
    public void onLoginWithProviderSuccess() {
        mFacebook.setEnabled(true);
        mGoogle.setEnabled(true);
        openSplashScreen();
    }

    @Override
    public void onLoginWithProviderFailed(Throwable throwable) {
        mFacebook.setEnabled(true);
        mGoogle.setEnabled(true);
        openLoginFailedDialog(MessageUtil.getResErrorOrServerErrorMessage(this, throwable));
    }

    @Override
    public void onForgotPassClick() {
        openRequestRestoreCodeActivity();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mGoogleLoginManager.onActivityResult(requestCode, resultCode, data);
        mFacebookLoginManager.setResult(requestCode, resultCode, data);
    }

    @Override
    public void onSuccessFacebookLogin(String token) {
        mFacebook.setEnabled(false);
        mLoginPresenter.signInUserWithProvider(Provider.FACEBOOK, token);
    }

    @Override
    public void onErrorFacebookLogin(String message) {
        MessageUtil.showSnackbar(rlLoginContent, R.string.authorization_failed);
    }

    @Override
    public void onGoogleLoginSucceeded(@NonNull String token) {
        mGoogle.setEnabled(false);
        mLoginPresenter.signInUserWithProvider(Provider.GOOGLE, token);
    }

    @Override
    public void onGoogleLoginFailed(String message) {
        MessageUtil.showSnackbar(rlLoginContent, R.string.authorization_failed);
    }

    @Override
    public void openPhoneApprove(String phone) {
        openApprovePhone(phone);
    }

    @Override
    public void providerUserNotFound(String provider, String token) {
        openRegisterPhone(provider, token);
    }

    private void attemptLogin() {
        etPassword.setError(ValidatorUtil.isPasswordValid(this, etPassword.getText().toString()));
        etPhone.setError(ValidatorUtil.isPhoneValid(this, etPhone.getText().toString()));
        if (!hasErrors()) {
            KeyboardUtil.hideSoftKeyboard(this);
            String phone = etPhone.getText().toString();
            String password = etPassword.getText().toString();
            mLoginPresenter.loginUser(phone, password);
        }
    }

    private boolean hasErrors() {
        boolean error = false;
        if (etPassword.getError() != null) {
            etPassword.requestFocus();
            error = true;
        }
        if (etPhone.getError() != null) {
            etPhone.requestFocus();
            error = true;
        }
        return error;
    }

    private void initViews() {

        ColorUtil.setProgressColor(pbProgress, R.color.green_bright);

        etPhone.setOnFocusChangeListener((view, b) -> {
            if (b) {
                PhoneUtil.addPrefix(etPhone);
                etPhone.requestFocus();
            }
        });

        setUpOnEditorActionListeners();

        setViewTreeObservers();

        etPassword.setFilters(new InputFilter[]{new InputFilter.LengthFilter(
                ValidatorUtil.MAX_PASSWORD_LENGTH)});

        cbShowPassword.setOnCheckedChangeListener((compoundButton, b) -> {
            if (!b) {
                ViewUtil.hidePassword(etPassword);
                ViewUtil.moveCursorToEnd(etPassword);
            } else {
                ViewUtil.showPassword(etPassword);
                ViewUtil.moveCursorToEnd(etPassword);
            }
        });
    }

    private void setUpOnEditorActionListeners() {
        etPhone.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                etPassword.requestFocus();
                ViewUtil.moveCursorToEnd(etPassword);
                return true;
            }
            return false;
        });

        etPassword.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                attemptLogin();
                return true;
            }
            return false;
        });
    }

    private void setViewTreeObservers() {
        etPassword.getViewTreeObserver().addOnGlobalLayoutListener(new ClearFocusLayoutListener(
                etPassword, new View[]{etPhone, etPassword}));
    }

    private void openLoginFailedDialog(String message) {
        LoginFailedDialog dialog = LoginFailedDialog.newInstance(message);
        dialog.setListener(this);
        dialog.show(getSupportFragmentManager(), LoginFailedDialog.class.getSimpleName());
    }

    private void openRegistrationActivity() {
        startActivity(RegistrationActivity.openRegistration(this));
        finish();
    }

    private void openApprovePhone(String phone) {
        startActivity(PhoneApproveActivity.start(this, phone, null, null));
        finish();
    }

    private void openRegisterPhone(String provider, String token) {
        startActivity(RegisterPhoneActivity.open(this, provider, token));
        finish();
    }

    private void openRequestRestoreCodeActivity() {
        RequestRestoreCodeActivity.start(this);
    }

    public void openSplashScreen() {
        SplashActivity.start(this);
    }
}
